﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class SceneMG : MonoBehaviour
{

    public void GotoGame()//startGame関数
	{
		//Screen.SetResolution(1920, 1080, true);
		SceneManager.LoadScene("SampleScene");
		
		Life.playerlife = 3;
		Life.playerlifeimage = 2;
       

    }
    public void ExitGame()//exitGame関数
	{
        Application.Quit();
    }

    public void LoadGame()//LoadGame関数
	{
		//Screen.SetResolution(1920, 1080, true);
		SceneManager.LoadScene("SampleScene");  
    }

    public void ReturnToTitle()//ReturnToTitle関数
	{
        SceneManager.LoadScene("Title");
    }
}
