﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossStat : MonoBehaviour
{

    public int BossHP;//BossHp
    public int BossAtttack1damage;//BossMeleeAttack1Damage
    public int BossAtttack2damage;//BossMeleeAttack2Damage
    public int BossAtttack3damage;//BossMeleeAttack3Damage
    public int Boss1SkillFiredamage;//Boss1FireSkillDamage
    public int Boss1SkillHanddamage;//Boss1HandSkillDamage
    public int Boss2SkillFiredamage;//Boss2FireSkillDamage
    public int Boss2SkillHanddamage;//Boss2HandSkillDamage
    public int BossCollsiondamage;//BossとPlayerが触れる時、Playerが受けるDamage

	

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
