﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SkillCoolTime : MonoBehaviour
{
    [SerializeField]
    PlayerMove script;
    public float CoolTimeD;//SkillDCoolTime
    public float CoolTimeS;//SkillSCoolTime
    public float CoolTimeA;//SkillACoolTime
    public Image skillpanelD;
    public Image skillpanelS;
    public Image skillpanelA;
	public Text skillDText;
	public Text skillSText;
	public Text skillAText;
	private float currentCoolTimeD;//CoolTimeDと同じ
    private float currentCoolTimeS;//CoolTimeSと同じ
    private float currentCoolTimeA;//CoolTimeAと同じ
    public bool skillD;//SkillCoolTimeDのCoroutineを反復防止
    public bool skillS;//SkillCoolTimeSのCoroutineを反復防止
    public bool skillA;//SkillCoolTimeAのCoroutineを反復防止
                     
    // Start is called before the first frame update
    void Start()
    {
        
        skillpanelD.fillAmount = 0;
        skillpanelS.fillAmount = 0;
        skillpanelA.fillAmount = 0;
		skillD = true;
		skillA = true;
		skillS = true;
    }

    // Update is called once per frame
    void Update()
    {
      
		if (script.CoolTimeStartD==true&&skillD)//script.CoolTimeStartDはSkillDが終わった時True
        {
		
			
            StartCoroutine((SkillCoolTime1(CoolTimeD)));//SkillDcoolTimeCoroutineStart  
        }
		if (script.CoolTimeStartS==true&&skillS)//script.CoolTimeStartSはSkillSが終わった時True
		{

			StartCoroutine((SkillCoolTime2(CoolTimeS)));

			
		}
		if (script.CoolTimeStartA==true && skillA)//script.CoolTimeStartAはSkillAが終わった時True
        {

			StartCoroutine((SkillCoolTime3(CoolTimeA)));

			
		}

           
    }

	IEnumerator SkillCoolTime1(float CoolTimeD)
	{
		skillD = false;//coroutine1回だけ行う
		Debug.Log("skillddddd");
		
		skillpanelD.fillAmount = 1;//panelのFillAmout=1
		currentCoolTimeD = CoolTimeD;//実際SkillDCooltime
		skillDText.text = "" + currentCoolTimeD;//textでCooltime表示
		StartCoroutine(SkillDCooltimeText());//text表示coroutine

		while (skillpanelD.fillAmount > 0)//panelのFillAmout=0まで実施
        {
			skillpanelD.fillAmount -= 1 * Time.smoothDeltaTime / CoolTimeD;

			yield return null;
		}
		script.CoolTimeStartD = false;//skillDを使うことができる
		skillD = true;
		yield break;//coroutine終了
		
	}
	IEnumerator SkillCoolTime2(float CoolTimeS)
	{
		skillS = false;//coroutine1回だけ行う
        skillpanelS.fillAmount = 1;//panelのFillAmout=1
        currentCoolTimeS = CoolTimeS;//実際SkillSCooltime
        skillSText.text = "" + currentCoolTimeS;//textでCooltime表示
        StartCoroutine(SkillSCooltimeText());//text表示coroutine
        while (skillpanelS.fillAmount > 0)//panelのFillAmout=0まで実施
        {
			skillpanelS.fillAmount -= 1 * Time.smoothDeltaTime / CoolTimeS;

			yield return null;
		}
		script.CoolTimeStartS = false;//skillSを使うことができる
        skillS = true;
		yield break;//coroutine終了

    }
	IEnumerator SkillCoolTime3(float CoolTimeA)
	{
		skillA = false;//coroutine1回だけ行う
        skillpanelA.fillAmount = 1;//panelのFillAmout=1
        currentCoolTimeA = CoolTimeA;//実際SkillACooltime
        skillAText.text = "" + currentCoolTimeA;//textでCooltime表示
        StartCoroutine(SkillACooltimeText());//text表示coroutine
        while (skillpanelA.fillAmount > 0)//panelのFillAmout=0まで実施
        {
			skillpanelA.fillAmount -= 1 * Time.smoothDeltaTime / CoolTimeA;

			yield return null;
		}
		script.CoolTimeStartA = false;//skillAを使うことができる
        skillA = true;
		yield break;//coroutine終了

    }

	IEnumerator SkillDCooltimeText()
	{
		while (currentCoolTimeD > 0)//CoolTime 0以上の場合表示
        {
			yield return new WaitForSeconds(1.0f);
			currentCoolTimeD -= 1.0f;
			skillDText.text = "" + currentCoolTimeD;
		}
		if(currentCoolTimeD <= 0)//CoolTime 0以下の場合表示しない
        {
			skillDText.text = "";
		}
  
        yield break;//coroutine終了
    }

	IEnumerator SkillSCooltimeText()
	{
		while (currentCoolTimeS > 0)//CoolTime 0以上の場合表示
        {
			yield return new WaitForSeconds(1.0f);
			currentCoolTimeS -= 1.0f;
			skillSText.text = "" + currentCoolTimeS;
		}
		if (currentCoolTimeS <= 0)//CoolTime 0以下の場合表示しない
        {
			skillSText.text = "";
		}
		yield break;//coroutine終了
    }
	IEnumerator SkillACooltimeText()
	{
		while (currentCoolTimeA > 0)//CoolTime 0以上の場合表示
        {
			yield return new WaitForSeconds(1.0f);
			currentCoolTimeA -= 1.0f;
			skillAText.text = "" + currentCoolTimeA;
		}
		if (currentCoolTimeA <= 0)//CoolTime 0以下の場合表示しない
        {
			skillAText.text = "";
		}
		yield break;//coroutine終了
    }
}

        
