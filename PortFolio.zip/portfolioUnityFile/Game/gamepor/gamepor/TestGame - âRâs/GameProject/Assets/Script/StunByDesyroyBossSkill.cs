﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StunByDesyroyBossSkill : MonoBehaviour
{
	public BossDamage BD;
	public BossMove BM;
    // Start is called before the first frame update
    void Start()
    {
		BD = GameObject.Find("bossDamaged").GetComponent<BossDamage>();
		BM = GameObject.Find("boss").GetComponent<BossMove>();
	}

    // Update is called once per frame
    void Update()
    {
		if (BD.stun||BM.moveFlag == -1)//BossがStunの状態の場合、SkillImpact削除
		{
			Destroy(gameObject);
		}
    }
}
