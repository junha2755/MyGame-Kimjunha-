﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkillFire : MonoBehaviour
{

    public float fireSpeed;
    private Rigidbody2D RB;

    // Start is called before the first frame update
    void Start()
    {
        RB = GetComponent<Rigidbody2D>();
        Destroy(gameObject, 1.5f);
        if (transform.localRotation.y > 0)//Playerが左を見ってSkillを使う場合、左に前進
        {
            RB.AddForce(new Vector2(-1, 0) * fireSpeed, ForceMode2D.Impulse);
        }
        else//Playerが右を見ってSkillを使う場合、右に前進
        {
            RB.AddForce(new Vector2(1, 0) * fireSpeed, ForceMode2D.Impulse);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
      
     

   
    }
}
