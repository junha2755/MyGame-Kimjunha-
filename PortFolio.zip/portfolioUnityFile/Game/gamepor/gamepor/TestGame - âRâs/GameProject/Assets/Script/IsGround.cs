﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IsGround : MonoBehaviour
{

	public PlayerMove player;

	 void Start()
	{
        player = GameObject.Find("Player").GetComponent<PlayerMove>();
	}

	void Update()
	{
		
	}
    
	

    void OnTriggerExit2D(Collider2D other)
	{
		if (other.gameObject.layer == 1)
		{
			player.isground = false;//地に離れる時

        }
	}


   

    
	 void OnTriggerStay2D(Collider2D other)
	{
		if (other.gameObject.layer == 1)
		{
			player.isground = true;//地にいる時
			player.jumpCount = 1;//2段目jumpができるようにする
		}
	}
	
}
