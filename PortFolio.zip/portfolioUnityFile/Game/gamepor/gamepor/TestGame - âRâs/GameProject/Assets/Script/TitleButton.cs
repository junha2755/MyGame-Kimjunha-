﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TitleButton : MonoBehaviour
{

    public Image StartButton;//startButton
    public Image ExitButton;//ExitButton

   public int selectedButton;// 0=start, 1=exit
	SceneMG MG;//sceneManger
    FadeManager FM;//fadeManager
    public bool activateButton;//trueの場合方向keyを動けます。
							   //falseの場合方向keyを動けません。

	BgmManager BG;//bgmManager

	public string ButtonSpaceSound;//spacebuttonを押すときのSound
	public string ButtonMoveSound;//spacebuttonを押すときのSound
								 
	void Start()
    {
        selectedButton = 0;// 0=start, 1=exit
		MG = GameObject.Find("Scene").GetComponent<SceneMG>();
        FM = GameObject.Find("FadeManager").GetComponent<FadeManager>();
        activateButton = true;
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
		Cursor.visible = false;//mouse cursor削除
    }

     void Awake()
    {
        Screen.SetResolution(1920, 1080, true);

   
    }
    // Update is called once per frame
    void Update()
    {
		
		if (Input.GetKeyDown(KeyCode.RightArrow)&&activateButton)//右の方向keyを押すとき
        {
            selectedButton = 1;//1 = exitButton
			BG.Play(ButtonMoveSound);//方向key効果音再生

			ExitButton.color = new Color32(246, 255, 4, 255);//exitButtonが黄色になる
			StartButton.color = new Color32(255, 255, 255, 255);//startButtonが白くなる
		}
        if (Input.GetKeyDown(KeyCode.LeftArrow) && activateButton)//左の方向keyを押すとき
		{
            selectedButton = 0;
			BG.Play(ButtonMoveSound);//方向key効果音再生
			ExitButton.color = new Color32(255, 255, 255, 255);//exitButtonが白くなる
			StartButton.color = new Color32(246, 255, 4, 255); //startButtonが黄色になる

		}

        if (Input.GetKeyDown(KeyCode.Space) && selectedButton == 0)//StartButtonを押すとき
        {
            activateButton = false;//falseの場合方向keyを動けません。
			BG.Play(ButtonSpaceSound);//spaceButton効果音再生
			FM.FadeOut();//画面が黒くなる
            StartCoroutine(Waittime());
        }

        if (Input.GetKeyDown(KeyCode.Space) && selectedButton == 1)//exitbuttonを押すとき
        {
            activateButton = false;//falseの場合方向keyを動けません。
			BG.Play(ButtonSpaceSound);//spaceButton効果音再生
			FM.FadeOut();//画面が黒くなる
			StartCoroutine(Waittime());
        }
    }

    IEnumerator Waittime()
    {
        yield return new WaitForSeconds(2f);//2秒待機
        if(selectedButton==0)
        MG.GotoGame();//selectedButton==0の場合ゲームスタート
		else if(selectedButton == 1)
         MG.ExitGame();//selectedButton==1の場合ゲーム終了
	}
}
