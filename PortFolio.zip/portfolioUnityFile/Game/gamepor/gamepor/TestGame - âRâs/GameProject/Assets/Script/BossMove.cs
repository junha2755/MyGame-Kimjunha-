﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossMove : MonoBehaviour
{
	public Collider2D playerCol;//playerCollider
	public Collider2D bosscol;//bossCollider
	public Animator anim;
	public Rigidbody2D rb;
	//public Collider2D GroundCollider;
	public BossGroundcheck BGC;
	public bool BossStart;//true =Bossが動ける false=Bossが動けない
	public float BossSpeed;//BossSpeed
	public bool moveFlagStop;//true =BossPattern関数を続けて実行する　false=BossPattern関数を実行しない
	public int moveFlag;//1~6　1:右に動く    2:左に動く    3:止める   4:fireSkill  5:handSkill   6:meleeAttack
	public GameObject impact;//BossMeleeAttackImpact
	public Transform ImpactPositon;//Impactposition
	public BossAttack BA;
	private Transform PlayerTranform;//PlayerTranform
    public BossStat bossStat;
    public bool canskill;//true = Skill実行できる   false=Skill実行できない
	public bool Boss2phase;//true = BossPhase2   false=BossPhase1
	public BossDamage BD;
	public Collider2D Boss1AttackCol;//Boss1Attackする時出るCollider
	public Collider2D Boss2AttackCol;//Boss2Attackする時出るCollider
	public BoxCollider2D BossDamageCol;//BossがDamageを与えるCollider
	public BoxCollider2D BossDamagedCol;//BossがDamageを受けるCollider
	public GameObject Player;//player

	

	BgmManager BG;

    public string boss1SkillFireSound;////効果音名前
    public string boss2SkillFireSound;////効果音名前

    public string boss1SkillHandSound;////効果音名前
    public string boss2SkillHandSound;////効果音名前

    public string Attack1Sound;////効果音名前
    public string Attack2Sound;////効果音名前
    public string Attack3Sound;////効果音名前
	bool set;
    // Start is called before the first frame update
    void Start()
	{

		Player = GameObject.Find("Player");
		playerCol = GameObject.Find("Player").GetComponent<BoxCollider2D>();
		bosscol = GameObject.Find("bossisGround").GetComponent<BoxCollider2D>();
		anim = GetComponent<Animator>();
		rb = GetComponent<Rigidbody2D>();
		BGC = FindObjectOfType<BossGroundcheck>();
		PlayerTranform = GameObject.Find("Player").GetComponent<Transform>();
		//GroundCollider = Boss.GetComponent<BoxCollider2D>();
		BossStart = false;
		//filp = true;
		//Lookright = false;
		StartCoroutine(BossAction());
		//Invoke("broke", 3f);
		moveFlagStop = false;
		BA = FindObjectOfType<BossAttack>();
		//chase = false;
        bossStat = GameObject.Find("BossStat").GetComponent<BossStat>();
        canskill = true;
        Boss2phase = false;
        BD = GameObject.Find("bossDamaged").GetComponent<BossDamage>();
		Boss1AttackCol = GameObject.Find("boss1AttackCol").GetComponent<CircleCollider2D>();
		Boss2AttackCol = GameObject.Find("boss2AttackCol").GetComponent<CircleCollider2D>();
        BossDamageCol = this.gameObject.transform.Find("BossCol").GetComponent<BoxCollider2D>();
       BossDamagedCol = this.gameObject.transform.Find("bossDamaged").GetComponent<BoxCollider2D>();
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
		

	}

// Update is called once per frame
void Update()
	{
		
	
		
		Physics2D.IgnoreCollision(bosscol, playerCol);//BoosとPlayerは実際に衝突無視
		if (rb.velocity.x == 0)//velocity.xが0の場合IdleAnimation実行する
		{
			anim.SetBool("Run", false);
		}
		else//velocity.xが0がない場合RunAnimation実行する
		{
			anim.SetBool("Run", true);
		}
		
		if (bossStat.BossHP>100)//BossHpが100以上Phase1
		{
			anim.SetLayerWeight(1, 0);
		}

		else if (bossStat.BossHP < 100)//BossHpが100以下になるとPhase2開始
		{
			anim.SetLayerWeight(1, 1);
            Boss2phase = true; //Phase2開始
			//phasing2 = true;

		}

        if(anim.GetCurrentAnimatorStateInfo(0).IsTag("Skill"))//SkillAnimationの時動けませんBossPhase1
		{
			rb.velocity = new Vector2(0, 0);
		}
		if(anim.GetCurrentAnimatorStateInfo(1).IsTag("Skill"))//SkillAnimationの時動けませんBossPhase2
		{
			rb.velocity = new Vector2(0, 0);
		}
		if (anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack"))//AttackAnimationの時動けませんBossPhase1
		{
			rb.velocity = new Vector2(0, 0);
		}
		if (anim.GetCurrentAnimatorStateInfo(1).IsTag("Attack"))//AttackAnimationの時動けませんBossPhase2
		{
			rb.velocity = new Vector2(0, 0);
		}

		if (anim.GetCurrentAnimatorStateInfo(0).IsTag("Stun"))//StunAnimationの時動けませんBossPhase1
		{
			rb.velocity = new Vector2(0, 0);
		}
		if (anim.GetCurrentAnimatorStateInfo(1).IsTag("Stun"))//StunAnimationの時動けませんBossPhase2
		{
			rb.velocity = new Vector2(0, 0);
		}
		if (anim.GetCurrentAnimatorStateInfo(0).IsTag("Start"))//StartAnimationの時動けませんBossPhase1
		{
			rb.velocity = new Vector2(0, rb.velocity.y);
		}
		if (anim.GetCurrentAnimatorStateInfo(1).IsTag("Start"))//StartAnimationの時動けませんBossPhase2
		{
			rb.velocity = new Vector2(0, rb.velocity.y);
                Destroy(GameObject.Find("StunImpact(Clone)"));//stunImpact破壊
        }


		if (BossStart && !moveFlagStop && !BD.stun && !anim.GetCurrentAnimatorStateInfo(1).IsTag("Start"))
		{
			if (moveFlag == 1 || moveFlag == 2 && bossStat.BossHP > 0)//1,2:bossがPlayerを追いかける
		    {
			 if (this.transform.position.x < Player.transform.position.x && BD.canFilp)
			 {
					
					rb.velocity = new Vector2(1.5f, 0) * BossSpeed;
				Vector3 Scale = this.transform.localScale;
				Scale.x = -1;
				this.transform.localScale = Scale;
			 }
			 else if (this.transform.position.x > Player.transform.position.x && BD.canFilp)
			 {
					
					rb.velocity = new Vector2(-1.5f, 0) * BossSpeed;
				Vector3 Scale = this.transform.localScale;
				Scale.x = 1;
				this.transform.localScale = Scale;
			 }
		    }
		}
	}
	



	public void Bosspattern()
	{
		if (BossStart && !moveFlagStop&&!BD.stun&&!anim.GetCurrentAnimatorStateInfo(1).IsTag("Start"))
		{

		
			if (moveFlag == 3)// 3:止める  
			{
				rb.velocity = new Vector2(0, 0);

			}
			
			if (moveFlag == 4 ) //fireSkill
			{
				
				StopCoroutine("BossAction");//coroutineStop
				BA.BossFireSkillS();//FireSkillCoroutine実行する
			}
			
			if (moveFlag == 5)//handSkill
            {
				
                StopCoroutine("BossAction");//coroutineStop
				BA.BossHandSkillS();//handSkillCoroutine実行する
			}
			if (moveFlag == 6 )//meleeAttack
			{
				
				StopCoroutine("BossAction");//coroutineStop
				BA.BossMeleeAttack();//meleeAttackCoroutine実行する

			}

		}
	}
  

	public void startMove()//Bossが動き始める
	{
			anim.SetBool("Start", true);//IdleAnimtaion実行
			BossStart = true;//Bossの攻撃を始める 
	}

    
  public IEnumerator BossAction()//BossPatternCoroutine
	{
		while (!BossStart)//まだ、Bossのstageが始まらない　BossStartがTrueになるとBossStageスタート
		{
			moveFlag = -1;
			yield return new WaitForSeconds(0.1f);
		}
		
		moveFlag = 10;//Bossのstageが始まる
		
			moveFlag = Random.Range(1, 7);
			
			Bosspattern();
			if (moveFlag == 1 || moveFlag == 2|| moveFlag == 3)
			{
				yield return new WaitForSeconds(3.0f);
			StartCoroutine(BossAction());
			}
			Debug.Log(moveFlag);
			yield return new WaitForSeconds(0.1f);

		

	}
	public void phase2Start()//BossPhase2Start
	{
		if (Boss2phase)
		{
			moveFlagStop = true;//Bosspattern関数中止

			StartCoroutine(Boss2startCorotine());//Boss2startCorotine実行する
			BossStart = false; //BossActionCoroutine中止


		}

	}


	IEnumerator Boss2startCorotine()
	{

		BossDamageCol.enabled = false; //BossがDamageを与えるCollider False
		BossDamagedCol.enabled = false;//BossがDamageを受けるCollider False
		yield return new WaitForSeconds(4f);
        anim.SetBool("Phase2", true);//Phase2Start
        BossDamageCol.enabled = true;//BossがDamageを与えるCollider true
		BossDamagedCol.enabled = true;//BossがDamageを受けるCollider true
		yield return new WaitForSeconds(2.0f);
        BossStart = true;//Bosspattern関数開始
        moveFlagStop = false;//Bosspattern関数開始
		StartCoroutine(BossAction());//BossActionCoroutineStart
	}


	public void Attackimpact()//AttackImpactの方向
	{
		if (this.transform.localScale.x > 0)//bossのlocalScale.xが０より大きい
		{
			Instantiate(impact, ImpactPositon.position, Quaternion.Euler(0, 0, 0));
		}
		else//bossのlocalScale.xが０より小さい
		{
			Instantiate(impact, ImpactPositon.position, Quaternion.Euler(0, 180, 0));//１８０度回転
		}
	}

	
	public void boss1AttackColTrue()//AttackColliderOnBossPhase1
	{
		Boss1AttackCol.enabled = true;
	}

	public void boss1AttackColFalse()//AttackColliderFalseBossPhase1
	{
		Boss1AttackCol.enabled = false;
	}
	

	public void boss2AttackColTrue()//AttackColliderOnBossPhase2
	{
		Boss2AttackCol.enabled = true;
	}

	public void boss2AttackColFalse()//AttackColliderFalseBossPhase2
	{
		Boss2AttackCol.enabled = false;
		
	}

	public void Attack2()//Attack2AnimationONBossPhase1
	{
		anim.SetInteger("Attack", 2);
	}

	public void Attack3()//Attack3AnimationONBossPhase1
	{
		anim.SetInteger("Attack", 3);

	}
	public void Attack22()//Attack2AnimationONBossPhase2
	{
		anim.SetInteger("Attack", 22);
	}

	public void Attack33()//Attack3AnimationONBossPhase2
	{
		anim.SetInteger("Attack", 33);

	}
	public void AttackFalse2()//AttackAnimationFalseBossPhase2
	{
		anim.SetInteger("Attack", 44);
		moveFlagStop = false;
	}

	public void AttackFalse()//AttackAnimationFalseBossPhase1
	{
        anim.SetInteger("Attack", 4);
        moveFlagStop = false;
    }

    public void SkillFalse()//SkillAnimationFalse
	{
        anim.SetInteger("Skill", 4);
        

    }
    

    public void boss1firesound()//skillSoundOn
    {
        BG.Play(boss1SkillFireSound);
    }

    public void boss2firesound()//skillSoundOn
	{
        BG.Play(boss2SkillFireSound);
    }

    public void boss1Handsound()//skillSoundOn
	{
        BG.Play(boss1SkillHandSound);
    }

    public void boss2Handsound()//skillSoundOn
	{
        BG.Play(boss2SkillHandSound);
    }

    public void Attack1SoundOn()//AttackSoundOn
    {
        BG.Play(Attack1Sound);
    }

    public void Attack2SoundOn()//AttackSoundOn
	{
        BG.Play(Attack2Sound);
    }

    public void Attack3SoundOn()//AttackSoundOn
	{
        BG.Play(Attack3Sound);
    }
  
}
