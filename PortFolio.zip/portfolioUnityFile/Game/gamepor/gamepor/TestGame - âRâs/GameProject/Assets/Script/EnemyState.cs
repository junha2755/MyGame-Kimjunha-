﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyState : MonoBehaviour
{
    public bool enemyMovestop;// trueの場合絶対に動けない　falseの場合動ける
	public float moveSpeed;//MoveSpeed
	public Rigidbody2D rigid;
	public SpriteRenderer ren;
	public Animator anim;
	public bool enemymove;//playerが追跡範囲にいると自動的動くことを防ぐ trueの場合動ける　falseの場合動けない

	public float AttackCoolTime;//meleeAttackCooltime
	public float ThrowCoolTime;//shurikenAttackCooltime
	float AttackNext;
	float ThrowNext;
	public GameObject Shuriken;//shurikenobject
	public Transform ShurikenP;//shurikenTransform
	public Collider2D enemyAttackcoll;//enemyが攻撃する時出るcolliderもしもPlayerが触れると(Player)にDamageを与える
	public bool filp;//true= 方向を変える　false=方向を変えない
	public bool Lookright;//右を見るならTrue 左を見るとFalse
    public bool stun;//true=stun状態　false=普通状態
    BgmManager BG;
    public string enemyAttackSound;//meleeAttackSound名前

    
    void Start()
	{
		rigid = GetComponent<Rigidbody2D>();
		ren = GetComponent<SpriteRenderer>();
		anim = GetComponent<Animator>();
		
		filp = true;
		Lookright = false;
		enemymove = true;
        stun = false;
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
    }

	public void attack()//meleeAttackの関数
	{
        
		if (Time.time > AttackNext && !anim.GetCurrentAnimatorStateInfo(0).IsTag("Throw")&&!stun)//meleeAttackCooltime経ったら攻撃できる、ShurikenAttack中には攻撃できない、stun状態には攻撃できない
		{
			AttackNext = Time.time + AttackCoolTime;
            BG.Play(enemyAttackSound);//sound実行
			anim.SetTrigger("EnemyAttack");//animation実行
		}
	}


	public void enemyMeleeAttackTrue()//meleeAttackcolliderが出る関数
	{
		enemyAttackcoll.enabled = true;
	}


	public void enemyMeleeAttackfalse()//meleeAttackcolliderを無くす関数
	{
		enemyAttackcoll.enabled = false;
	}


	public void enemyThrow()//ShurikenAttack
	{
		if (Time.time > ThrowNext && !anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack")&&!stun)//shurikenAttackCooltime経ったらShurikenAttackできる、meleeAttack中にはShurikenAttackできない、stun状態にはShurikenAttackできない
		{
           
			ThrowNext = Time.time + ThrowCoolTime;
			anim.SetTrigger("EnemyThrow");//animation実行
			Instantiate(Shuriken, ShurikenP.position, Quaternion.identity);//shuriken生成

		}

	}

	// Update is called once per frame
	void FixedUpdate()
	{
	
		if (anim.GetCurrentAnimatorStateInfo(0).IsTag("stun"))//stun状態にTrue
        {
            stun = true;
        }
        else if (!anim.GetCurrentAnimatorStateInfo(0).IsTag("stun"))//stun状態ではない場合はfalse

		{
            stun = false;
        }
        

        if (rigid.velocity.y != 0)//velocity.yが0ではない場合idleAnimation実行
		{
            anim.SetBool("Movement", false);
        }

        if (rigid.velocity.x==0)//velocity.xが0の場合idleAnimation実行
		{
			anim.SetBool("Movement", false);
		}
		else if(rigid.velocity.x != 0&&rigid.velocity.y==0) //velocity.xが0ではない場合、velocity.y==0の場合　RunAnimation実行
		{
			anim.SetBool("Movement", true);
		}
	

		if (anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack") || anim.GetCurrentAnimatorStateInfo(0).IsTag("Throw") || anim.GetCurrentAnimatorStateInfo(0).IsTag("stun"))
		{
			rigid.velocity = new Vector2(0, rigid.velocity.y);//stun,meleeAttack.ShurikenAttackのAnimationが実行する場合はvelocity.xは０つまりX軸は動けない

		}

        if (rigid.velocity.y < 0)//enemyが落ちる場合はX軸は動けない
		{
            rigid.velocity = new Vector2(0, rigid.velocity.y);
            
        } 

		Filp();
        

        

    }

  

	
    public void Filp()//見る方向を変える関数
	{
		if (filp&&!stun)
		{
            
			if (rigid.velocity.x > 0 && !Lookright || (rigid.velocity.x < 0) && Lookright)//rigid.velocity.x > 0なら右を見る　 rigid.velocity.x < 0なら左を見る
			{
				Lookright = !Lookright;
				Vector3 Scale = this.transform.localScale;
				Scale.x *= -1;
				this.transform.localScale = Scale;
			}
            
            
		}

	}


	

	
}
    

