﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
	
	public EnemyState state;//enemyState Script

	 void Start()
	{
		
	}

	// Start is called before the first frame update


	void OnTriggerStay2D(Collider2D other)
	{
		if (other.tag == "Player")
		{

			state.attack();//playerが範囲の中にいるとmeleeAttack実行
			

		}
	}
}
