﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Menu : MonoBehaviour
{
    public Image ReturnTotitleButton;//0
    public Image ReturnTogameButton;//1

    public GameObject titlebutton;//0
    public GameObject gamebutton;//1

    public int selectedButton; // 0 = GotoTitle ,   1 =ゲームに戻る

    FadeManager FM;
    public bool activateButton;

    BgmManager BG;

    public bool MenuOn;//true = MenuOn ,  false=MenuOff
    public Image black;
    SceneMG SM;
    PlayerMove PM;
	
    // Start is called before the first frame update
    void Start()
    {
        selectedButton = 0;// 0=gotoTitle, 1=ゲームに戻る
        activateButton = true;     
        MenuOn = false;
        SM = GameObject.Find("SceneManager").GetComponent<SceneMG>();
        PM = GameObject.Find("Player").GetComponent<PlayerMove>();
		FM = GameObject.Find("FadeManager").GetComponent<FadeManager>();
		activateButton = true;

	}

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape)&&!MenuOn&&!PM.PlayerStop)//readyText、warngingtextが出現している時不可能
        {
            Time.timeScale = 0;//GameStop
            titlebutton.SetActive(true);//buttonOn
            gamebutton.SetActive(true);//buttonOn
            black.color = new Color32(255, 255, 255, 150);//画面少し暗くなる
            MenuOn = true;//
			
			
        }
		

        if (Input.GetKeyDown(KeyCode.DownArrow) && MenuOn&& activateButton)//↓keyを押すと
        {
            selectedButton = 1;//ゲームに戻るbutton選択


            ReturnTotitleButton.color = new Color32(255, 255, 255, 255);//buttonが選択されてない状態
            ReturnTogameButton.color = new Color32(255, 35, 0, 255);//buttonが選択される状態,   buttonが赤くなる
        }
        if (Input.GetKeyDown(KeyCode.UpArrow) && MenuOn && activateButton)//↑keyを押すと
        {
            selectedButton = 0; ;//Titleに戻るButton選択

            ReturnTotitleButton.color = new Color32(255, 35, 0, 255);//buttonが選択される状態,  buttonが赤くなる
            ReturnTogameButton.color = new Color32(255, 255, 255, 255);//buttonが選択されてない状態
        }

        if (MenuOn&&Input.GetKeyDown(KeyCode.Space) && selectedButton == 0)//SpaceButtonを押すと、Titleに戻る
        {

			activateButton = false;//button移動が出来ない
			Time.timeScale = 1;
			SM.ReturnToTitle();//TitleSceneに戻る
			
			
        }

        if (MenuOn && Input.GetKeyDown(KeyCode.Space) && selectedButton == 1)//SpaceButtonを押すと、Titleに戻る
        {
            Time.timeScale = 1;
            titlebutton.SetActive(false);//buttonOff
            gamebutton.SetActive(false);//buttonOff
            black.color = new Color32(255, 255, 255, 0);//画面が元に戻る
            MenuOn = false;//MenuOff
            selectedButton = 0;
            ReturnTotitleButton.color = new Color32(255, 35, 0, 255);//Buttonを元に戻る
            ReturnTogameButton.color = new Color32(255, 255, 255, 255);//Buttonを元に戻る


        }
    }

	

}
