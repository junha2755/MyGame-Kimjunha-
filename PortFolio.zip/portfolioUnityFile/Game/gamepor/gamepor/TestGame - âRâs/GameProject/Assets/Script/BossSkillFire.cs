﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSkillFire : MonoBehaviour
{
    public Animator anim;
    public bool biggerfire;//Falseなら大きくなっている中、Trueなら完全に大きくなった
	public Transform boss;//BossのTransform
	public Rigidbody2D rb;
    public float power;//発射power
	public BossMove BS;
	public GameObject fireDestroy;//skillの破片
	BgmManager BG;
    public string firesound;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        biggerfire = false;
        boss = GameObject.Find("boss").GetComponent<Transform>();
        rb = GetComponent<Rigidbody2D>();
        BS = GameObject.Find("boss").GetComponent<BossMove>();
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        StartCoroutine(fireSoundCoroutine());
    }

    // Update is called once per frame
    void Update()
    {
        if (!biggerfire)//Falseなら大きくなっている中
		{
            anim.SetLayerWeight(1, 0);//anim.SetLayer0実行
		}
        else if (biggerfire)//Trueなら完全に大きくなった
		{
            anim.SetLayerWeight(1, 1);//anim.SetLayer1実行
		}
    }



    public void Skillfirebigger()//biggerfireがTrueになるようにする関数
	{
        biggerfire = true;
    }

    public void SkillFire()//Skillを前に発射するようにする関数
	{
       // BS.skillmove = true;
        StartCoroutine(SkillfireCorotine());
       
    }

    IEnumerator SkillfireCorotine()
    {


		// if (BS.skillmove){ }

		yield return new WaitForSeconds(0.5f);
            if (boss.transform.localScale.x > 0)//BossのlocalScale.x>0なら左の方向に発射
		{

                rb.AddForce(rb.velocity = new Vector2(-1, 0) * power, ForceMode2D.Impulse);
               
            }
            if (boss.transform.localScale.x < 0)//BossのlocalScale.x<0なら右の方向に発射
		{
                rb.AddForce(rb.velocity = new Vector2(1, 0) * power, ForceMode2D.Impulse);
                
            }
            rb.gravityScale = 7;//重力によってSkillが下に向ける
       

      

    }
	 void OnTriggerStay2D(Collider2D other)
	{
		if (other.gameObject.layer == 1 || other.tag == "Player" && biggerfire)//Skillがplayerや壁、地面衝突すると破片生成
		{
			GameObject.Instantiate(fireDestroy, this.transform.position, Quaternion.identity);
			Destroy(gameObject);
		}
	}
    IEnumerator fireSoundCoroutine()//soundcoroutine
	{
        yield return new WaitForSeconds(1.0f);
        if(this.gameObject)//skillがあると効果音再生
			BG.Play(firesound);
    }

}
