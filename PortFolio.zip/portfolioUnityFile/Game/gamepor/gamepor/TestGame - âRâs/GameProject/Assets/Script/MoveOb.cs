﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveOb : MonoBehaviour
{

    public Transform pos1, pos2;//オブジェクトが動く範囲　Pos1に向けた後　Pos2に向ける
    public float speed;
    public Transform startPos;//pos1

    Vector3 nextPos;//オブジェクトが行く方向
    void Start()
    {
        nextPos = startPos.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position == pos1.position)//オブジェクトがpos1.positionに触れると、pos2.positionに方向を変える
        {
            nextPos = pos2.position;
        }
        if (transform.position== pos2.position)//オブジェクトがpos2.positionに触れると、pos1.positionに方向を変える
        {
            nextPos = pos1.position;
        }

        transform.position = Vector3.MoveTowards(transform.position, nextPos, speed * Time.deltaTime);//オブジェクトがnextPosに向ける
    }


    private void OnDrawGizmos()//DrawLine表示
    {
        Gizmos.DrawLine(pos1.position, pos2.position);
    }


}
