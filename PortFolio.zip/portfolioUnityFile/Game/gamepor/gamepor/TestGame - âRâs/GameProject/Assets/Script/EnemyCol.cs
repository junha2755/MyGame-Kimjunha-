﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCol : MonoBehaviour
{
    public Collider2D playerCol;//playerCollider
    public Collider2D enemycol;//enemyCollider
	public Animator anim;
    EnemyState Es;
    public Transform enemy;//enemyTransform
    public int vector=2;//enemyの進行方向
    // Start is called before the first frame update
    void Start()
    {
        playerCol = GameObject.FindGameObjectWithTag("Player").GetComponent<BoxCollider2D>();
        enemycol = GetComponent<BoxCollider2D>();
		anim = this.gameObject.GetComponentInParent<Animator>();
        Es = gameObject.transform.parent.GetComponent<EnemyState>();
        enemy = gameObject.transform.parent.GetComponent<Transform>();
	}

    // Update is called once per frame
    void Update()
    {
        if (Es.enemymove && !Es.stun && !Es.enemyMovestop)
        {
            Es.rigid.velocity = new Vector2(-vector, Es.rigid.velocity.y) * Es.moveSpeed;//実際にenemyを動く
		}
          
        
       
         Physics2D.IgnoreCollision(enemycol, playerCol);//playerColliderとenemyColliderは実際に衝突無視

	}


	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "EnemyStopCol")//EnemyStopColに衝突すると進行方向が反対方向に変える
		{
			vector *= -1;
		}

	}









}
