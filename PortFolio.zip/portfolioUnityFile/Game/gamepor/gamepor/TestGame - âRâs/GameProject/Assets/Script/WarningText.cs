﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WarningText : MonoBehaviour
{
    Text text;
    PlayerMove PM;
    BossMove BM;
    BossStat bossStat;
	public GameObject bossHPbar;//BossHpBar
	BgmManager BG;
	public string WarningSound;//効果音名前
    public string BossBgm;//効果音名前


    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<Text>();
        PM = GameObject.Find("Player").GetComponent<PlayerMove>();
        BM = GameObject.Find("boss").GetComponent<BossMove>();
        bossStat = GameObject.Find("BossStat").GetComponent<BossStat>();
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
	}
    void Update()
    {

		

	}
    public IEnumerator TextFlash()//Text瞬き
    {
        //PM.MyAnimator.Play("idle");
        int countTime = 0;
        BM.rb.gravityScale = 1;//上にいったBossの重力を１にして、Bossを落ちる
        while (countTime < 10)
        {
			
            if (countTime % 2 == 0)
                text.color = new Color32(255, 11, 0, 255);
           
            else
                text.color = new Color32(255, 11, 0, 0);

            yield return new WaitForSeconds(0.5f);
			
			

			countTime++;
			


		}
        text.color = new Color32(255, 11, 0, 0);//WarningTextがなくなる
        bossHPbar.SetActive(true);//BossHP活性化
		yield return new WaitForSeconds(1.0f);
		
		PM.PlayerStopFalse();//Playerを動ける
        BM.startMove();//Bossの行動開始
		
    }

	public IEnumerator WarningSoundCoroutine()//WarningTextSound
	{
		int countTime = 0;
		while (countTime < 5)
		{
			
			
				BG.Play(WarningSound);//効果音再生
            yield return new WaitForSeconds(1f);
			countTime++;

		}

		BG.Play(BossBgm);//BGM再生
        BG.SetLoop(BossBgm);//BGMLoopOn

    }
	

}
