﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class PlayerMove : MonoBehaviour
{
	public SkillCoolTime SCT;
	public float Speed;//playerのSpeed
	public float shurikenCooltime;//shurikenのcooltime
	public Rigidbody2D Mybody;
	public Animator MyAnimator;
	public bool facingRight;//true = 右を見る　False = 左を見る
	public bool isattack;//MeleeAttackKeyを押す時True
	private bool isjump2;//2段目jumpkeyを押す時True
	public bool isground;//地にいる時True, 空中にいる時False
	public bool isjump;//jumpKeyを押す時True
	public float jumpForce;//jumpPower
	public float jumpForce2;//2段目jumpPower
	public bool jumpAttack;//jumpmeleeAttackする時True
	public EdgeCollider2D Sword1;
	public EdgeCollider2D Sword2;
	public int jumpCount;
   
    public Transform skillposition;//Skillposition
    public GameObject fireskill;//Skillimpact
    public GameObject lighting;//Skillimpact
    public Transform lightingPostion;//Skillposition
    public GameObject lighting2;//Skillimpact
    public Transform lightingPostion2;//Skillposition
    public GameObject chidori;//Skillimpact
    public Transform chidoriPostion;//Skillposition
    public bool chidorispeed;//SkillDが前に前進する時のspeed
	public int chidoriskillspeed;//SkillDが前に前進する時のspeed
    public float time = 0f;//shurikenChargeする時のtime
  
	public Transform lightingPostion3;//Skillposition
    public GameObject lighting3;//Skillimpact
    public GameObject shuriken;//Skillimpact
    public Transform shurikenPosition;//Skillposition
    private float nextSkillTime1 = 0;//SKillA nextSkillTime1 = Time.time + skillUi.CoolTimeA;　この時間が経った後skillAを使うことができる
    private float nextSkillTime2 = 0;//SkillS nextSkillTime2 = Time.time + skillUi.CoolTimeS;　この時間が経った後skillSを使うことができる
    private float nextSkillTime3 = 0;//SkillD nextSkillTime3 = Time.time + skillUi.CoolTimeD;　この時間が経った後skillDを使うことができる
    private float nextShuriken = 0;
    public bool CoolTimeStartD;//trueの時SkillcoolTimeがスタート
    public bool CoolTimeStartS;//trueの時SkillcoolTimeがスタート
    public bool CoolTimeStartA;//trueの時SkillcoolTimeがスタート
    public int shrikennumber;//shurikenの数
    public float nextShurikenChargeTime;//この時間が経った後shrikennumber+1
    [SerializeField]
    SkillCoolTime skillUi;
    public Text shrikenText;//shurikentext
    public GameObject swordslash;//Skillimpact
	public GameObject jumpswordslash;//Skillimpact
    public Transform swordslashTran;//Skillposition
    public Transform jumpswordslashTran;//Skillposition
    public SpriteRenderer spriteren;
	//public Collider2D PlayerDamageColl;//PlayerのDamageCollider
	public float dashjump;
	BoxCollider2D PlayerCol;//PlayerのDamageCollider
    public bool dashing;//dashの時True 普通の時False
	public float horizontal;//方向keyによって値が変える　←=-1, →=1
	public float knockBackPower;//playerがDamageを受ける時Knockback
   public  float gravityscale;//重力
    public bool skilling;//SkillKey A,S,D,を共に押す時Skillが共に使えないようにするBool
    public bool canSkill;//False = PlayerがDamageを受ける時Skillを使えない true=Skillを使うことができる
    public bool PlayerStop;// True = playerを操ることができない、False=playerを操ることができる
  
    public string AtkSound;//効果音名前
    public string SkillASound;//効果音名前
    public string SkillDSound;//効果音名前
    public string FireSound;//効果音名前
    public string ThrowSound;//効果音名前
    public string JumpSound;//効果音名前
                            //public string explosion1;
                            //public string explosion2;

    
	BgmManager BG;
    void Start()
    {
        
        PlayerStop = true;
        facingRight = true;
        isattack = false;
        CoolTimeStartD = false;
        CoolTimeStartS = false;
        CoolTimeStartA = false;
       Mybody = GetComponent<Rigidbody2D>();
		MyAnimator = GetComponent<Animator>();
        shrikennumber = 10;
		spriteren = GetComponent<SpriteRenderer>();
		SCT = FindObjectOfType<SkillCoolTime>();
		PlayerCol = GameObject.Find("Damage").GetComponent<BoxCollider2D>();
		//wallHopDirection.Normalize();
		//wallJumpDirection.Normalize();
        Invoke("Playerstart", 1f);
		gravityscale = Mybody.gravityScale;
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        skilling = false;
    }

  

	void Update()
    {
        
        Layer();
        if (!PlayerStop)// False = playerを操ることができる
        {
			InputControl();
			JUMP();
			Move();
            Filp();
            AttackControl();
            resetValue();
			Damaged();
			chidoriskill();

		}


        if (PlayerStop) //False = playerを操ることができる
            MyAnimator.SetFloat("run", 0);
		
		if (PlayerStop) //False = playerを操ることができる
        {
            horizontal = 0;
			Mybody.velocity = new Vector2(0, 0);
            //canSkill = false;
        }
		
        if (!PlayerStop) //False = playerを操ることができる
            horizontal = Input.GetAxis("Horizontal");

        canSkill = true;

        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("damage"))//Damageを受ける時Skillを使えない
        {
            canSkill = false;
        }


		if (shrikennumber > 10)//Shurikenの数は最大10
		{
			shrikennumber = 10;
		}


		if (shrikennumber < 10)//chargingTimeが経った後Shurikenの数+1
        {
			time += Time.deltaTime;
			if (time > nextShurikenChargeTime)
			{
				shrikennumber++;
				time = 0;
			}
		}
		shrikenText.text = "X  " + shrikennumber;//Shurikenの数表示




    }

    public void PlayerStopTrue()//Playerを止めさせる
    {
        PlayerStop = true;
		Mybody.gravityScale = 0;//重力0
    }
    public void PlayerStopFalse()//Playerを操ることができる
    {
        PlayerStop = false;
		Mybody.gravityScale = gravityscale;//重力が戻る
    }

    public void Playerstart()//ゲームが始まる時開始
    {
        spriteren.color = new Color32(255, 255, 255, 255);//Playerが見える(ゲームが始まる時はPlayerが見えない)
        MyAnimator.Play("PlayerStart");//PlayerStartAnimation実行
        PlayerStartCorotine();
       

    }

    public void PlayerStartCorotine()
    {
        StartCoroutine(StartCor());//coroutineStart
        IEnumerator StartCor()
        {


            yield return new WaitForSeconds(2.0f);
            MyAnimator.SetBool("PlayerStart", true);//IdleAnimation実行
            PlayerStopFalse();//Playerを操ることができる

        }
    }

  

   
    public void chidoriskill()//key Sを押すと前に前進する時発動する関数
	{
		if (chidorispeed)
		{
			if (this.transform.localScale.x > 0)//playerが右を見ると
			{
				Mybody.AddForce(new Vector2(chidoriskillspeed, 0), ForceMode2D.Impulse);
            }
			else if (this.transform.localScale.x < 0)//playerが左を見ると
            {
				Mybody.AddForce(new Vector2(-chidoriskillspeed, 0), ForceMode2D.Impulse);
			}
		
		}


	}

   

    public void Move()
	{
      

        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("damage"))//DamageAnimationが実行する時方向キーでは動けない
        {
            horizontal = 0;
            //isground = false;
        }
        if (MyAnimator.GetCurrentAnimatorStateInfo(1).IsTag("damage"))//空中DamageAnimationが実行する時方向キーでは動けない
        {
            horizontal = 0;
        }
        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Start"))//StartAnimation実行する状態は動けない
        {
            Mybody.velocity = new Vector2(0, 0);
        }
        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Portal"))//PlayerがPortalを触れる時動けない
        {
            Mybody.velocity = new Vector2(0, 0);
        }

        if (!isground)//地に離れる時RunAnimationは再生できない
		{
			MyAnimator.SetFloat("run", 0);
			
		}
	
        
        if (horizontal == 0)//方向keyを押さない
        {
            this.transform.position = new Vector2(transform.position.x, transform.position.y);
        }
        
       
        Mybody.velocity = new Vector2(horizontal * Speed, Mybody.velocity.y);//方向keyによって左右動く

        if (!PlayerStop)//Playerを操ることができる場合
            MyAnimator.SetFloat("run", Mathf.Abs(horizontal));//horizontalによって右左操作
		
		if (Input.GetKey(KeyCode.LeftShift) && isground&&MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("run"))//LeftShiftを押したまま動くと速度が2倍
        {
			Mybody.velocity = new Vector2(horizontal * Speed * 2, Mybody.velocity.y);
            dashing = true;//

        }
        if (!Input.GetKey(KeyCode.LeftShift) && isground)//LeftShiftを押さない場合
        {
            dashing =false;//
        }


        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("throw")) //ShurikenをAnimationを実行する状態は動けない

        {
			Mybody.velocity = new Vector2(0, 0);
		}
        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Portal")) //PortalAnimationを実行する状態は動けない
        {
            Mybody.velocity = new Vector2(0, 0);
        }

		if (!isground&& MyAnimator.GetCurrentAnimatorStateInfo(1).IsTag("damage"))//AirDamageAnimationを実行すると下に落ちる
        {
			MyAnimator.SetLayerWeight(1,1);
			Mybody.velocity = new Vector2(0, -10);
            
            
        }
        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Dead") || MyAnimator.GetCurrentAnimatorStateInfo(1).IsTag("Dead"))//死んだ時動けない
        {
            horizontal = 0;
            Speed = 0;
            Mybody.velocity = new Vector2(0, 0);
        }
  

    }

    public void Damaged()//playerがDamageを受けるとKnockBack
	{
		if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("damage"))//DamageAnimationを実行する
        {
         
			if (facingRight)//右を見る場合
				Mybody.AddForce(new Vector2(-1, 0)*knockBackPower, ForceMode2D.Impulse);//KnockBack
            else//左を見る場合
                Mybody.AddForce(new Vector2(1, 0)*knockBackPower, ForceMode2D.Impulse);//KnockBack
        }

	}
    


	public void JUMP()
	{

        /*
		if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack")
            || MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill")
            || MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("throw") 
            || MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill2")
            )
		{
			isjump = false;
		}
        */
        if (isjump && isground)//jumpKeyを押した後
        {
            //&& !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill2")

            //isground = false;
            if (dashing) Mybody.AddForce(new Vector2(0, jumpForce) * dashjump, ForceMode2D.Impulse);//playerがDash状態でJumpすると、Jumpが最も高い
            else Mybody.AddForce(new Vector2(0, jumpForce), ForceMode2D.Impulse);//playerを空中に浮かぶ
        }
        if (Mybody.velocity.y > 0 && !isground)//jumpした後JumpAnimation実行する
		{
			MyAnimator.SetBool("jump", true);

		}
		if (Mybody.velocity.y < 0 && !isground)//jumpした後落ちる時landAnimation実行する
		{
			MyAnimator.SetBool("jump2", false);
			MyAnimator.SetBool("land", true);
			MyAnimator.SetBool("jump", false);
			
		}
		if (isground)
		{
			MyAnimator.SetBool("land", false);//jumpして後落ちた後landAnimationを中止

        }
		if (!isground && jumpCount > 0 && isjump2  )///jumpした後2段目jumpできる、  jumpした後 jumpCount+1　地に触れたら jumpCount+1
		{

            MyAnimator.SetBool("jump2", true);
			Mybody.velocity = new Vector2(0, jumpForce2);
			jumpCount--;
		}
		

		
       
    }
   

	public void Filp()
	{
      if(facingRight&&horizontal < 0 || !facingRight && horizontal > 0)//PlayerFilp, 方向Keyの右を押すとPlayerが右を見る、方向Keyの左を押すとPlayerが左を見る
        {
			if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack")|| MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill")|| MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill2"))//MeleeAttack.skillを使う時Playerの方向変換ができない
				return;
			facingRight = !facingRight;
			Vector3 TheScale = this.transform.localScale;
			TheScale.x *= -1;
			this.transform.localScale = TheScale;
		}

	}
	public void ifPlayerBossStartFilp()//bossstageに入ると必ず右を見る
	{
		if (!facingRight)
		{
			facingRight = true;
			Vector3 theScale = this.transform.localScale;
			theScale.x *= -1;
			this.transform.localScale = theScale;
		}
		
	}

	public void AttackControl()
	{
       
		if (!isground && jumpAttack)
		{
			MyAnimator.SetTrigger("jumpattack");
		}
		
		if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack"))
		{
			Mybody.velocity = new Vector2(0, 0);
		}
        if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill")|| MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill2"))
        {
            Mybody.velocity = new Vector2(0, 0);
        }
        
	}

	public void InputControl()
	{
		if (Input.GetKeyDown(KeyCode.Z) && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Damage"))//DamageAnimationの状態ではない場合、z keyを押した時
		{			
			isattack = true;
			jumpAttack = true;
			
			combo();//Attack実行
			
		}

		if (Input.GetKeyDown(KeyCode.X))//jumpkeyを押したあとisjumpがtrueになってjumpができる
		{
			isjump = true;
           
;
		}
		if(MyAnimator.GetCurrentAnimatorStateInfo(1).IsTag("Jump")&& Input.GetButtonDown("Jump"))//1番目Jump状態にもう一回jumpKeyを押すisjump2がtrueになって2段目jumpができる
        {
			isjump2 = true;
		}


        if (Input.GetKeyDown(KeyCode.A) && isground && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && Time.time > nextSkillTime1 && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Damage") && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("throw"))//AttackAnimation,DamageAnimation状態にはSkillを使うことはできない、地にいる時とCooltimeが0になる場合Skillを使うことはできる
        {
           
            if (SCT.skillA&& canSkill && !skilling) //Key D,S,A,Fは一緒に使うことはできない
            {
               
                nextSkillTime1 = Time.time + skillUi.CoolTimeA;
                skill2();
                skilling = true;
            }

        }

        if (Input.GetKeyDown(KeyCode.S) && isground && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && Time.time > nextSkillTime2  && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Damage"))//AttackAnimation,DamageAnimation状態にはSkillを使うことはできない、地にいる時とCooltimeが0になる場合Skillを使うことはできる
        {
          
            if (SCT.skillS && canSkill && !skilling)   //Key D,S,A,Fは一緒に使うことはできない
            {
                nextSkillTime2 = Time.time + skillUi.CoolTimeS;
                    skill();                
                  skilling = true;
            }
         
        }
      
        if (Input.GetKeyDown(KeyCode.D) && isground &&!MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && Time.time > nextSkillTime3  && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Damage"))//AttackAnimation,DamageAnimation状態にはSkillを使うことはできない、地にいる時とCooltimeが0になる場合Skillを使うことはできる
        {
          
            if (SCT.skillD && canSkill&&!skilling)   //Key D,S,A,Fは一緒に使うことはできない
            {
                nextSkillTime3 = Time.time + skillUi.CoolTimeD;
                skill3();
                skilling = true;
            }
        }
		if(Input.GetKeyDown(KeyCode.F) && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && Time.time > nextShuriken&&!MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill2") && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Skill")&& isground && !MyAnimator.GetCurrentAnimatorStateInfo(0).IsTag("Damage"))
        {//AttackAnimation,DamageAnimation,SkillAnitmationの状態にはShurikenを使うことはできない、

            if ( shrikennumber>0 && canSkill && !skilling)   //Key D,S,A,Fは一緒に使うことはできない
            {
               
                nextShuriken = Time.time + shurikenCooltime;
                ShurikenSkill();
                skilling = true;
                shrikennumber--;
                shrikenText.text = "X  " + shrikennumber;
                
            }
       
		}
        if(Input.GetKeyDown(KeyCode.F) && isground== false && Time.time > nextShuriken)
        {
          
            if ( shrikennumber > 0)//shurikenの数が0以上
            {
				nextShuriken = Time.time + shurikenCooltime;//cooltimeが経った後
				jumpShurikenSkill();
                shrikennumber--;//shuriken=-1
                shrikenText.text = "X  " + shrikennumber;//数表示
                
            }
     
        }
	}
    public void jumpShurikenSkill()
    {
        StartCoroutine(jumpShurikenCor());
        IEnumerator jumpShurikenCor()
        {
            MyAnimator.SetBool("Jumpthrow", true);//skillAnimation実行
            BG.Play(ThrowSound);//効果音再生
            yield return new WaitForSeconds(0.21f);
            MyAnimator.SetBool("Jumpthrow", false);//skillAnimation中止
		
			if (facingRight)//Playerが右を見る
            {
                Instantiate(shuriken, shurikenPosition.position, Quaternion.Euler(0, 0, -90));//shuriken生成
            }
            else if (!facingRight)//Playerが左を見る
            {
                Instantiate(shuriken, shurikenPosition.position, Quaternion.Euler(0, 0, 90));//shuriken生成
            }
           

        }

    }
	public void SkillMutekifalse()//無敵の状態Off
	{
        //PlayerDamageColl.enabled = true;
        PlayerCol.enabled = true;

    }
	public void SkillMutekitrue()//無敵の状態On
    {
        //PlayerDamageColl.enabled = false;
        PlayerCol.enabled = false;
    }


	public void ShurikenSkill()
	{
		StartCoroutine(ShurikenCor());
		IEnumerator ShurikenCor()
		{
			MyAnimator.SetBool("Shuriken", true);//skillAnimation実行
            BG.Play(ThrowSound);//効果音再生
            yield return new WaitForSeconds(0.21f); 
            MyAnimator.SetBool("Shuriken", false);//skillAnimation中止

            //Shuriken = false;
            if (facingRight)//Playerが右を見る
            {
				Instantiate(shuriken, shurikenPosition.position, Quaternion.Euler(0, 0, -90));//shuriken生成
            }
			else if (!facingRight)//Playerが左を見る
            {
				Instantiate(shuriken, shurikenPosition.position, Quaternion.Euler(0, 0, 90));//shuriken生成
            }
            skilling = false;

        }	
	}

    public void skill3()//skillD
    {
        StartCoroutine(chidori2());
        IEnumerator chidori2()
        {
			BG.Play(SkillDSound);//効果音再生
                          
            PlayerCol.enabled = false;//Player無敵状態On
            MyAnimator.SetBool("chidori", true);//skillAnimation実行
			yield return new WaitForSeconds(0.1f);
			Instantiate(lighting3, lightingPostion3.position, Quaternion.identity);//skillImpact生成

            yield return new WaitForSeconds(0.4f);
			
			chidorispeed = true;//playerが前に早く前進
			if (facingRight)//Playerが右を見る
            {
                Instantiate(chidori, chidoriPostion.position, Quaternion.Euler(0,0,0));//skillImpact生成
            }

            else if(!facingRight)//Playerが左を見る
            {
                Instantiate(chidori, chidoriPostion.position, Quaternion.Euler(0, 180, 0));//skillImpact生成

            }
			
			yield return new WaitForSeconds(0.25f);
			chidorispeed =false;//playerが止まる
            MyAnimator.SetBool("chidori", false);//skillAnimation中止
            PlayerCol.enabled = true;//Player無敵状態Off
            CoolTimeStartD = true;//coolTimeがスタート
            skilling = false;
            //cooltime = true;

         


        }

            
    }

    public void skill2()//skillA
    {
        StartCoroutine(chidorinagaskill());
        IEnumerator chidorinagaskill()
        {
			PlayerCol.enabled = false;//Player無敵状態On
            BG.Play(SkillASound);//効果音再生
            Debug.Log("chchchchchcstart");
			//Chidorinagashi = true;
			MyAnimator.SetBool("chidorinagashi", true);//skillAnimation実行
            var parent = this.gameObject;
            GameObject.Instantiate(lighting2, lightingPostion2.position, Quaternion.identity).transform.parent = parent.transform;//skillImpact生成
            yield return new WaitForSeconds(0.7f);

            GameObject.Instantiate(lighting, lightingPostion.position, Quaternion.identity).transform.parent = parent.transform;//skillImpact生成
            yield return new WaitForSeconds(0.3f);
			PlayerCol.enabled = true;//Player無敵状態Off
            MyAnimator.SetBool("chidorinagashi", false);//skillAnimation中止

            CoolTimeStartA = true;//coolTimeがスタート
            skilling = false;
            Debug.Log("chchchchchcend");

			//Chidorinagashi = false;
		}
    }

    public void skill()//skillS
    {
        StartCoroutine(howaguskill());

        IEnumerator howaguskill()
       {
            //FireSkill = true;
            PlayerCol.enabled = false;//Player無敵状態On
            MyAnimator.SetBool("Skill", true);//skillAnimation実行
            BG.Play(FireSound);//効果音再生
            yield return new WaitForSeconds(0.6f);
		
            MyAnimator.SetBool("Skill", false);//skillAnimation中止

            if (facingRight)//Playerが右を見る
            {
                Instantiate(fireskill, skillposition.position, Quaternion.Euler(0, 0, 0));//skillImpact生成
            }
            else if (!facingRight)//Playerが左を見る
            {
                Instantiate(fireskill, skillposition.position, Quaternion.Euler(0, 180, 0));//skillImpact生成
            }
            PlayerCol.enabled = true;//Player無敵状態Off
            CoolTimeStartS = true;//coolTimeがスタート
            skilling = false;

        }

       
    }

	public void resetValue()//keyを押さない場合False
	{
		isattack = false;
		isjump = false;
		jumpAttack = false;
		isjump2 = false;
  

    }



	public void Layer()//Layer0=地にいる時　Layer1=空中にいる時
	{
		if (!isground)
		{
			MyAnimator.SetLayerWeight(1, 1);
		}
		else
		{
			MyAnimator.SetLayerWeight(1, 0);
		}
	}

	public void ComboFalse()//MeleeAttackをした後Animationを戻る
	{
		MyAnimator.SetInteger("combo", 4);
		
	}

 

	public void combo()//PlayerMeleeAttackCombo
	{
		if (isattack&&isground&&!MyAnimator.GetCurrentAnimatorStateInfo(0).IsName("Attack3"))//z keyを押す時isAttackがtrue地にいる、Attack3終わった後時Attack1発動
		{
			MyAnimator.SetInteger("combo", 1);
            
        }
		if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsName("Attack1")&&Input.GetButtonDown("meleeAttack")&&isground)//Attack1状態z keyを押すAttack2発動
        {
			MyAnimator.SetInteger("combo", 2);
           
        }
		if (MyAnimator.GetCurrentAnimatorStateInfo(0).IsName("Attack2") && Input.GetButtonDown("meleeAttack")&&isground)//Attack2状態z keyを押すAttack3発動
        {
			MyAnimator.SetInteger("combo", 3);
           
        }
	}
    public void attackSound()//効果音再生
    {
        BG.Play(AtkSound);
    }

	public void At1True()//PlayerがMeleeAttack1する時Attack1ColliderOn
	{
		Sword1.enabled = true;
	}

	public void At1False()//AttackCollider1Off
	{
		Sword1.enabled = false;
	}


	public void At2True()//PlayerがMeleeAttack2する時Attack2ColliderOn
    {
        Sword2.enabled = true;
 
      }

	public void At2False()//AttackCollider2Off
    {
		Sword2.enabled = false;
	}


	public void At3True()//PlayerがMeleeAttack3する時出るImpact
	{
		
        if (facingRight)//Playerが右を見る
        {
            Instantiate(swordslash, swordslashTran.position, Quaternion.Euler(0, 0, 0));
        }
        else if (!facingRight)//Playerが左を見る
        {
            Instantiate(swordslash, swordslashTran.position, Quaternion.Euler(0, 180, 0));
        }
    }



	public void JumpAtTrue()//jumpAttackする時出るimpact
	{
		
        if (facingRight)//Playerが右を見る
        {
            Instantiate(jumpswordslash, jumpswordslashTran.position, Quaternion.Euler(0, 0, -25));
        }
        else if (!facingRight)//Playerが左を見る
        {
            Instantiate(jumpswordslash, jumpswordslashTran.position, Quaternion.Euler(0, 180, -25));
        }
    }


	public void jumpSound()//効果音再生
	{
		BG.Play(JumpSound);
	}


	
}
