﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EarthSkill : MonoBehaviour
{
	public GameObject SkillHand;//Boss2の下から出るHandskill
	public BossMove BM;//BossMove Script

	BossDamage BD;//BossDamageScript
	BgmManager BG;//BgmManagerScript
	public string Handsound;//効果音名前
	void Start()
	{
		BM = GameObject.Find("boss").GetComponent<BossMove>();
		BD = GameObject.Find("bossDamaged").GetComponent<BossDamage>();
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        if (BD.currentHp <= 0)//BossのHpが０になると削除
		{
			Destroy(gameObject);
		}
        
	}

	public void False()//BossのAnimationをIdleに戻るようにする関数
	{
		BM.SkillFalse();
	}


	public void EarthSkillAppearance()//Skill生成ようにする関数
	{
		
		var parent = this.gameObject;
		GameObject.Instantiate(SkillHand, this.transform.position, Quaternion.identity).transform.parent = parent.transform;//skillのおやをこのオブジェクトに設定
		BG.Play(Handsound);//効果音再生
      
    }

}
