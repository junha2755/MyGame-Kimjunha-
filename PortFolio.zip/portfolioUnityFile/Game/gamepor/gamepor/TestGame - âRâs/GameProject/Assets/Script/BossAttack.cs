﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossAttack : MonoBehaviour
{
	public Animator anim;
	//public BoxCollider2D BossCol;
    
	public BossMove BM;
	public Rigidbody2D rb;
	//public bool AttackOn;
	public GameObject Player;
	public Transform bossTranform;
    public GameObject SkillFire;//SkillfireObject
    public GameObject SkillFire2;//SkillfireObject2
    public Transform SkillFirePosition;//SkillfirePosition
    public Transform SkillFire2Position;//SkillfirePosition2
	public BossDamage BD;
	//public bool canAttack;
	public GameObject SkillEarth;//handskillObject2
	Vector2 EarthSkillPostion;   //handskillposition2
	public GameObject Boss1Skill2;//handskillObject
	public Transform Boss1Skill2Position;//handskillposition
	BossStat BS;
   

    // Start is called before the first frame update
    void Start()
	{
		Player = GameObject.Find("Player");
		anim = GameObject.Find("boss").GetComponent<Animator>();
		//BossCol = GameObject.Find("bossAttack").GetComponent<BoxCollider2D>();
		BM = GameObject.Find("boss").GetComponent<BossMove>();
		rb = GameObject.Find("boss").GetComponent<Rigidbody2D>();
		//AttackOn = false;
		bossTranform = GameObject.Find("boss").GetComponent<Transform>();
        BD = GameObject.Find("bossDamaged").GetComponent<BossDamage>();
		//canAttack = true;
        BS = GameObject.Find("BossStat").GetComponent<BossStat>();
       

    }

    void Update()
    {
        if (anim.GetCurrentAnimatorStateInfo(1).IsTag("Stun") || (anim.GetCurrentAnimatorStateInfo(0).IsTag("Stun")))//Stun状態になるとBossは動けない
        {
            rb.velocity = new Vector2(0, 0);
        }
      
    }
    public void BossMeleeAttack()//MeleeAttack関数
	{
		if (!BD.stun  && !anim.GetCurrentAnimatorStateInfo(0).IsTag("Skill") && BS.BossHP > 0)// stun状態がない場合、skillAnimationがない場合、BossHP>0の場合
		{
			
			//BM.filp = false;
			
			StartCoroutine(Attack());//AttackCoroutine実行する
		}
	}

	


	IEnumerator Attack()
	{

		BM.moveFlagStop = true;//Bosspattern 中止
							   
		if (bossTranform.transform.position.x < Player.transform.position.x)//PlayerがBossより右にいると右の方向にmeleeAttack
		{
			Vector3 Scale = bossTranform.transform.localScale;
			Scale.x = -1;
			bossTranform.transform.localScale = Scale;
		}
		else if (this.transform.position.x > Player.transform.position.x)//PlayerがBossより左ににいると左の方向にmeleeAttack
		{
			Vector3 Scale = bossTranform.transform.localScale;
			Scale.x = 1;
			bossTranform.transform.localScale = Scale;
		}
		if (!BM.Boss2phase)//phase1
		{
			anim.SetInteger("Attack", 1);//meleeAttackAnimation実行する
		}
		else//phase2
		{
			anim.SetInteger("Attack", 11);//meleeAttackAnimation実行する
		}

		yield return new WaitForSeconds(3f);
		StartCoroutine(BM.BossAction());//Bossの行動coroutineStart
	}

    public void BossFireSkillS()
    {
        if (!anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && BS.BossHP > 0)
        {
            //BM.filp = false;
            //StopCoroutine(BM.BossAction());//Bossの行動coroutineStop
			if (BM.moveFlag == 4&& !BM.Boss2phase)//phase1の場合
			{
				StartCoroutine(Boss1Skill1Corotine());//Boss1FireSkill
              
            }

			else if(BM.moveFlag == 4&& BM.Boss2phase)//phase2の場合
			{
				StartCoroutine(Boss2SkillCorotine());//Boss2FireSkill
               
			}
		}
		
    }

	public void BossHandSkillS()
	{
		if (!anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack") && BS.BossHP > 0)
		{
            //BM.filp = false;
            //StopCoroutine(BM.BossAction());
            if (BM.moveFlag == 5 && !BM.Boss2phase)
			{
				StartCoroutine(Boss1Skill2Corotine());//Boss1HandSkill
                
            }
			else if (BM.moveFlag == 5 && BM.Boss2phase)
			{
				StartCoroutine(Boss2Skill2Corotine());//Boss2handSkill
                
            }
		}
		
	}

	IEnumerator Boss2SkillCorotine()//boss2fireskill
	{
		SkillFilp();
		
		if (!BD.stun)//stun状態ではない場合
		{
			anim.SetInteger("Skill", 7);//fireSkillAnimation実行する

			Instantiate(SkillFire2, SkillFire2Position.position, Quaternion.identity);//fireskill生成
		}
		
        yield return new WaitForSeconds(3.0f);
		SkillBool();
    }

    IEnumerator Boss1Skill1Corotine()//boss1fireskill
    {
		SkillFilp();
		
		if (!BD.stun)//stun状態ではない場合
		{
			anim.SetInteger("Skill", 5);//fireSkillAnimation実行する
			Instantiate(SkillFire, SkillFirePosition.position, Quaternion.identity);//fireskill生成
           
        }
		
		yield return new WaitForSeconds(3.0f);
		SkillBool();
    }

	IEnumerator Boss1Skill2Corotine()//Boss1HandSkill
	{
		SkillFilp();
		
		if (!BD.stun)//stun状態ではない場合
		{
			anim.SetInteger("Skill", 6);//handSkillAnimation実行する
			Instantiate(Boss1Skill2, Boss1Skill2Position.position, Quaternion.identity);//handskill生成

		}

		yield return new WaitForSeconds(3.0f);
		SkillBool();
	}



	IEnumerator Boss2Skill2Corotine()//Boss2handSkill
	{
		
		SkillFilp();
		Transform TR;
		TR = GameObject.Find("Player").GetComponent<Transform>();//playerの位置を探す
		EarthSkillPostion.Set(TR.position.x,-2);//skillpositionを作る
		
		if (!BD.stun)//stun状態ではない場合
		{
			anim.SetInteger("Skill", 8);//handSkillAnimation実行する
			yield return new WaitForSeconds(0.4f);
			GameObject.Instantiate(SkillEarth, EarthSkillPostion, Quaternion.identity);//handskill生成

		}

		
		yield return new WaitForSeconds(3.0f);
		SkillBool();
	}



	public void SkillFilp()
	{
		BM.moveFlagStop = true;//pattern中止
	
		if (bossTranform.transform.position.x < Player.transform.position.x&&BS.BossHP>0)//PlayerがBossより右にいると右の方向に向ける
		{
            
			Vector3 Scale = bossTranform.transform.localScale;
			Scale.x = -1;
			bossTranform.transform.localScale = Scale;
            
        }
		else if (bossTranform.transform.position.x > Player.transform.position.x && BS.BossHP > 0)//PlayerがBossより左ににいると左の方向に向ける
		{
			Vector3 Scale = bossTranform.transform.localScale;
			Scale.x = 1;
			bossTranform.transform.localScale = Scale;
          
        }
	}

	public void SkillBool()//pattern中止
	{
		BM.moveFlagStop = false;//pattern開始
		//BM.moveFlag = 3;
		StartCoroutine(BM.BossAction());//coroutine開始
	}
	

}
