﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameBGM : MonoBehaviour
{
     BgmManager BG;
	public string bgm;//効果音名前
    public string readySound;//効果音名前
    // Start is called before the first frame update
    void Start()
    {
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();

		
		Invoke("ReadyEffectSound", 0.8f);//ゲームがスタートした後 0.8秒後実行
    }

	 void Awake()
	{
		
	}

	// Update is called once per frame
	void Update()
    {
        
    }
   
    
    public void ReadyEffectSound()
    {
        BG.Play(readySound);//readySound再生
		BG.Play(bgm);//BGM再生
        BG.SetLoop(bgm);//BGMはLoop再生
    }


}
