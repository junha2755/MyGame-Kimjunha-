﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttackint : MonoBehaviour
{
	public int playerFirstAttackint;//PlayerFirstAttackDamage
	public int playerSecondAttackint;//playerSecondDamage
	public int playerthirdAttackint;//playerthirdAttackDamage
	public int jumpAttackint;//PlayerjumpAttackintDamage
	public int playerSkillA;//playerSkillADamage
	public int playerSkillS;//playerSkillSDamage
	public int playerSkillD;// playerSkillDDamage
	public float StunTime;//stun時間
	public int kunaiInt;//kunaiIntDamage
}
