﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1Skill : MonoBehaviour
{
    public GameObject boss1SkillImpact;
  
    public void impact()
    {
        var parent = this.gameObject;
        GameObject.Instantiate(boss1SkillImpact, this.transform.position, Quaternion.identity).transform.parent = parent.transform;
       //StartCoroutine(StunCorotine());
    }
  
}
