﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ClearText : MonoBehaviour
{
	public Text cleartext;//clearした後出るText
	BossStat BS;
	public GameObject boss;//BossGameobject
	SceneMG SMG;
    public GameObject endingCredit;//ending object
    
    public GameObject Player;//player
	BgmManager BG;
	public string ClearSound;//効果音名前
    public string EndingSound;//効果音名前
                              // Start is called before the first frame update
    void Start()
    {
		BS = GameObject.Find("BossStat").GetComponent<BossStat>();
		boss = GameObject.Find("boss");
		cleartext = GetComponent<Text>();
		SMG = GameObject.Find("SceneManager").GetComponent<SceneMG>();
        
        Player = GameObject.Find("Player");
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
	}

    // Update is called once per frame
    void Update()
    {
		
    }

    public void gotoTitle()//TitleSceneに戻る
    {

		cleartext.color = new Color32(52, 192, 41, 255);//clearTextが出現
		BG.Play(ClearSound);//効果音再生
        StartCoroutine(WaitTimeTitle());//coroutineStart
    }
		
    IEnumerator WaitTimeTitle()
    {
		yield return new WaitForSeconds(4.0f);
		endingCredit.SetActive(true);//endingCreditが出現
        Player.SetActive(false);//playerがなくなる
		BG.Play(EndingSound);//効果音再生
        yield return new WaitForSeconds(20f);
            SMG.ReturnToTitle();//20秒後TitleSceneに戻る

    }

	
}
