﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FadeManager : MonoBehaviour
{
    public Image white;//白いimage
    public Image black;//黒いimage


	private Color color;

    private WaitForSeconds waitTime = new WaitForSeconds(0.01f);//0.01秒待機


    public void FadeOut(float _speed = 0.02f)//画面が段々黒くなる
    {
        
        StartCoroutine(FadeOutCoroutine(_speed));//coroutine実行
    }

    IEnumerator FadeOutCoroutine(float _speed)//画面が段々黒くなるcoroutine
	{
        color = black.color; //黒いimageのcolor
		while (color.a < 1f)//黒いimageの透明度1になるまで実行
		{
            color.a += _speed;//黒いimageの透明度が段々上がる
			black.color = color;//黒いimageのcolor
			yield return waitTime;//0.01秒待機

		}
    }

    public void FadeIn(float _speed = 0.02f)//黒いimageの透明度0になる
	{
        
        StartCoroutine(FadeInCoroutine(_speed));//coroutine実行
	}

    IEnumerator FadeInCoroutine(float _speed)//黒いimageの透明度0になるcoroutine
	{
        color = black.color;//黒いimageのcolor
		while (color.a > 0f)//黒いimageの透明度0になるまで実行
		{
            color.a -= _speed;//黒いimageの透明度が段々落ちる
			black.color = color;//黒いimageのcolor
			yield return waitTime;//0.01秒待機
		}
    }












	public void FadeOutWhite(float _speed = 0.02f)//画面が段々白くなるcoroutine
	{

		StartCoroutine(FadeOutCoroutineWhite(_speed));//coroutine実行
	}

	IEnumerator FadeOutCoroutineWhite(float _speed)//画面が白くなる完全に白くなる
	{
		color = white.color;//白いimageのcolor
		while (color.a < 1f)//白いimageの透明度1になるまで実行
		{
			color.a += _speed;//白いimageの透明度が段々上がる
			white.color = color;//白いimageのcolor
			yield return waitTime;//0.01秒待機

		}
	}

	public void FadeInWhite(float _speed = 0.02f)//白い画面の透明度0になる
	{

		StartCoroutine(FadeInCoroutineWhite(_speed));//coroutine実行
	}

	IEnumerator FadeInCoroutineWhite(float _speed)//白いimageの透明度0になるcoroutine
	{
		color = white.color;//白いimageのcolor
		while (color.a > 0f)//白いimageの透明度0になるまで実行
		{
			color.a -= _speed; //白いimageの透明度が段々落ちる
			white.color = color;//白いimageのcolor
			yield return waitTime;//0.01秒待機
		}
	}



}
