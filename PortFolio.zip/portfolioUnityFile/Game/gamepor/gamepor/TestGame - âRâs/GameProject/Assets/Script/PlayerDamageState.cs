﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerDamageState : MonoBehaviour
{
	[SerializeField]
	PlayerMove player; //PlayerMove
    public bool PlayerDamaged;// true = PlayerがDamageを受けない　false= PlayerがDamageを受ける


    public Slider playerHealth;//playerHPSlider
    public int FullHp;//PlayerFullHp
	public int currentHp;//現在のplayerHP
	public float knockBackForce;// PlayerがDamageを受けた時後ろに弾く
    public Attackint attackint;
	public GameObject playerOb;//playerGameObject
	public Rigidbody2D rb;
	private BossStat BS;
	public PlayerMove PM;
    public GameObject DieText;//死んだ時出るText
    public SceneMG SM;
    public GameObject []PlayerLife;//PlayerのlifeImage死んだ時一つずつlifeImageがなくなる
                                   // GameObject playerLifeImage;
    BgmManager BG;
	public string DamagedSound;//効果音名前
    public string DeadSound;//効果音名前
    public string bgm;//効果音名前
    public Collider2D PlayerCol; //PlayerがDamageを受けるCollider
                                 //BoxCollider2D col;

    BossDamage BD;
    // Start is called before the first frame update
    void Start()
    {
        BD = GameObject.Find("bossDamaged").GetComponent<BossDamage>();
        SM = GameObject.Find("SceneManager").GetComponent<SceneMG>();
        PlayerDamaged = false;
        playerHealth.maxValue = FullHp;
        currentHp = FullHp;
        playerHealth.value = currentHp;
        playerOb = GameObject.Find("Player");
        rb = GameObject.Find("Player").GetComponent<Rigidbody2D>();
        //shuriken = FindObjectOfType<EnemyShuriken>();
        //state = FindObjectOfType<EnemyState>();
        BS = GameObject.Find("BossStat").GetComponent<BossStat>();
        PM = GameObject.Find("Player").GetComponent<PlayerMove>();
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();

        for (int i =Life.playerlife; i<3; i++)//playerが1回死んだ、Image1個削除　、playerが2回死んだ、Image2個削除、playerが3回死んだ、Image3個削除
        {
            Destroy(PlayerLife[i]);
            }
		
        PlayerCol = GetComponent<BoxCollider2D>();

    }

	void Update()
	{
        if (BD.currentHp <= 0)//BossのHpが0の場合Playerは無敵状態
        {
            PlayerDamaged = true;
        }


    }


	public void ifplayerDamaged(int damaged)
	{
		PlayerDamaged = true;//PlayerDamaged = trueになったらdamageを受けない

        if (player.isground)//地にいる時
			player.MyAnimator.SetTrigger("Damage");//DamageAnimation実行

        else//空中にいる時
            player.MyAnimator.SetTrigger("AirDamage");//AirDamageAnimation実行

        currentHp -= damaged;//体力を落ちる
			playerHealth.value = currentHp;//体力表示

        StartCoroutine(Beat());//PlayerピカピカになるCoroutine

		

	}


	


	void OnTriggerStay2D(Collider2D other)//Normal enemy
	{
		if (other.tag == "enemy" && !PlayerDamaged)//enemyと衝突の時
		{
			ifplayerDamaged(attackint.Attackpushint);
		}

       

        else if (other.tag == "enemyShuriken" && !PlayerDamaged)//enemyShurikenと衝突の時
        {
			ifplayerDamaged(attackint.ShurikenAttackint);
		}
		else if (other.tag == "enemyMeleeAttack" && !PlayerDamaged)//enemyMeleeAttackと衝突の時
        {
			ifplayerDamaged(attackint.MeleeAttackint);
		}



		else if (other.tag == "BossCol" && !PlayerDamaged)//Bossと衝突の時
        {
			ifplayerDamaged(BS.BossCollsiondamage);
		}

		else if (other.tag == "BossAttack1" && !PlayerDamaged)//BossMeleeAttackと衝突の時
        {
			ifplayerDamaged(BS.BossAtttack1damage);
		}

		else if (other.tag == "BossAttack2" && !PlayerDamaged)//BossMeleeAttack2と衝突の時
        {
			ifplayerDamaged(BS.BossAtttack2damage);
		}
		else if (other.tag == "BossAttack3" && !PlayerDamaged)//BossMeleeAttack3と衝突の時
        {
			ifplayerDamaged(BS.BossAtttack3damage);
		}
		else if (other.tag == "Boss1SkillFire" && !PlayerDamaged)//Boss1FireSkillと衝突の時
        {
			ifplayerDamaged(BS.Boss1SkillFiredamage);
		}
		else if (other.tag == "Boss1SkillHand" && !PlayerDamaged)//Boss1HandSkillと衝突の時
        {
			ifplayerDamaged(BS.Boss1SkillHanddamage);
		}
		else if (other.tag == "Boss2SkillFire" && !PlayerDamaged)//Boss2FireSkillと衝突の時
        {
			ifplayerDamaged(BS.Boss2SkillFiredamage);
		}
		else if (other.tag == "Boss2SkillHand" && !PlayerDamaged)//Boss2HandSkillと衝突の時
        {
			ifplayerDamaged(BS.Boss2SkillHanddamage);
		}
	}


   void OnTriggerEnter2D(Collider2D other)
    {
		
        if (other.tag == "deadZone")//Playerが穴に落ちる時
        {
            ifplayerDamaged(attackint.deadzone);
			rb.gravityScale = 0;//重力0
            Destroy(PlayerCol);//直ぐにdead
		
        }
    }







    IEnumerator Beat()
		{
		
		int countTime = 0;
        if (currentHp > 0)
        {
			BG.Play(DamagedSound);
			
            while (countTime < 10)//Playerの瞬き
            {

                if (countTime % 2 == 0)
                    player.spriteren.color = new Color32(255, 255, 255, 90);//color.Aの値を変更
                else
                    player.spriteren.color = new Color32(255, 255, 255, 180);//color.Aの値を変更

                yield return new WaitForSeconds(0.2f);

                countTime++;//countTimeが10になると普通の状態に戻る
                player.spriteren.color = new Color32(255, 255, 255, 255);//color.Aの値が戻る


            }

            yield return null;
            PlayerDamaged = false;//PlayerDamaged = falseになったらdamageを受ける
        }

        if (currentHp <=0)//PlayerHpが0になると
        {
            rb.gravityScale = 0;//重力0
            PlayerCol.enabled = false;//PlayerがDamageを受けるCollider= false
            BG.Stop(bgm);//bgmStop
			BG.Play(DeadSound);//効果音再生
			DieText.SetActive(true);//DeadTextが出る
            PM.MyAnimator.SetBool("Dead", true);//deadAnimation実行
            player.spriteren.color = new Color32(255, 255, 255, 90);//playerが濁す

            Destroy(PlayerLife[Life.playerlifeimage]);//playerLifeImageを破壊
            yield return new WaitForSeconds(2f);
            
            player.spriteren.color = new Color32(255, 255, 255, 0);//Playerが見えない
            yield return new WaitForSeconds(4f);
            Life.playerlife -= 1;//PlayerLifeは元3, 死んだ時 -1
            Life.playerlifeimage -= 1;//playerlifeimageは元2  ,死んだ時 -1
            if (Life.playerlife == 0)//PlayerLifeが0になるとTitle画面に戻る
            {
                SM.ReturnToTitle();
            }
            if (Life.playerlife != 0)//PlayerLifeが0ではないとLoadGame
            {
                SM.LoadGame();
            }
            
        }

    }






}
