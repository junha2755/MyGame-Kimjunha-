﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthHeal : MonoBehaviour
{

    public PlayerDamageState PDS;//PlayerDamageState scprit
	BgmManager BG;//BgmManager scprit
	public string HealthSound;//効果音名前
							 
	void Start()
    {
        PDS = GameObject.FindGameObjectWithTag("PlayerDamage").GetComponent<PlayerDamageState>();
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player"&&PDS.currentHp>0)//playerがHeartを触れると
        {
			BG.Play(HealthSound);//効果音再生
			PDS.currentHp += 5;//HP5回復
            PDS.playerHealth.value = PDS.currentHp;//HPBarに表示
            Destroy(gameObject);//heart破壊
        }
    }
}
