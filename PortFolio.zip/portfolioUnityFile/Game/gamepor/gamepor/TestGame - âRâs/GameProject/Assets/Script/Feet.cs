﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Feet : MonoBehaviour
{
    public GameObject Player;
    
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.Find("Player");
    }
    /*
     void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.tag=="Isground")
        {
            Player.transform.parent = this.gameObject.transform;
        }
 
    }

    private void OnCollisionExit2D(Collision2D other)
    {
        if (other.gameObject.tag == "Isground")
        {
            Player.transform.parent = null;
        }
    }
    */
    void OnTriggerStay2D(Collider2D other)//Moving objectにPlayerがいる場合一生に動く
    {
        if (other.gameObject.tag == "Isground")
        {
            Player.transform.parent = this.gameObject.transform;
        }
    }

     void OnTriggerExit2D(Collider2D other)//Moving objectとPlayer親子関係ではない
	{
        if (other.gameObject.tag == "Isground")
        {
            Player.transform.parent = null;
        }
    }
}
