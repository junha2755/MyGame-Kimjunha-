﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireSkillDestroySound : MonoBehaviour
{
    BgmManager BG;//bgmScript

    public string firedestroySound;//効果音名前
								   // Start is called before the first frame update
	void Start()
    {
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        BG.Play(firedestroySound);//効果音再生
    }

  
}
