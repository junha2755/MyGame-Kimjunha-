﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStop : MonoBehaviour
{
    public Collider2D PlayerCol;//playerCollider
    public Collider2D thisCol;//thisCollider
   

     void Start()
    {
        PlayerCol = GameObject.Find("Player").GetComponent<Collider2D>();
        thisCol = GetComponent<Collider2D>();
        
    }
	void FixedUpdate()
	{
		Physics2D.IgnoreCollision(PlayerCol, thisCol);//playerColliderとthisColliderは実際に衝突無視
	}




   

   
}
