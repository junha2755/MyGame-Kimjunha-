﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShuriken : MonoBehaviour
{
	public float speed;//Shurikenの速度
	private Rigidbody2D rd;

	//public GameObject state;
	
	public Transform playerTranform;//playerのTransform
    public string enemyShuriken;//効果音名前
    BgmManager BG;
    // Start is called before the first frame update
    void Start()
    {
        //state = GameObject.Find("Ninja");
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        playerTranform = GameObject.Find("Player").GetComponent<Transform>();
		rd = GetComponent<Rigidbody2D>();
        BG.Play(enemyShuriken);//効果音再生
		if (playerTranform.position.x > this.transform.position.x)//PlayerPosition.xがShurikenPosition.xより大きくなると
		{
			rd.AddForce(new Vector2(1, 0) * speed, ForceMode2D.Impulse);//Shurikenは右に向ける
		}

	    if (playerTranform.position.x < this.transform.position.x)//PlayerPosition.xがShurikenPosition.xより小さくなると
		{
			rd.AddForce(new Vector2(-1, 0) * speed, ForceMode2D.Impulse);//Shurikenは左に向ける
		}
	     
    }

    // Update is called once per frame
    void Update()
    {
		this.transform.Rotate(new Vector3(0, 0, 720) * Time.deltaTime);//Shurikenはいつも360度回転

	}
}
