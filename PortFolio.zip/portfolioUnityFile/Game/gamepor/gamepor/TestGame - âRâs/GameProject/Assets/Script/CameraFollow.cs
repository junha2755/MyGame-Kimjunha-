﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    private Transform PlayerTransform;//playerの位置
    [SerializeField]
    private float MaxX;//cameraが動けるxの最大範囲
    [SerializeField]
    private float MinX;//cameraが動けるxの最小範囲
	[SerializeField]
    private float MaxY;//cameraが動けるyの最大範囲
	[SerializeField]
    private float MinY;//cameraが動けるyの最小範囲


	public float offset;


	[SerializeField]
	private float MaxX2;//BossStageにplayerがいる時cameraが動けるxの最大範囲
	[SerializeField]
	private float MinX2;//BossStageにplayerがいる時cameraが動けるxの最小範囲
	[SerializeField]
	private float MaxY2;//BossStageにplayerがいる時cameraが動けるyの最大範囲
	[SerializeField]
	private float MinY2;//BossStageにplayerがいる時cameraが動けるyの最小範囲


	PortalBoss PB;//portalBoss スクリプト

	// Start is called before the first frame update
	void Start()
    {
        PlayerTransform = GameObject.FindGameObjectWithTag("Player").transform;
		PB = GameObject.FindGameObjectWithTag("BossRoom").GetComponent<PortalBoss>();

		

	




	}


	// Update is called once per frame
	void LateUpdate()
    {
        Cursor.visible = false;//MouseCurSor 削除

        Vector3 temp = transform.position;//このcameraのtransform.position

		temp.x = PlayerTransform.position.x; //playerのtransform.position.x

		temp.x += offset;//cameraとplayer距離を一定に維持

        transform.position = temp;// このcameraのtransform.positionをtempで設定

		if (!PB.bossRoom)//BossStageにいない時False
		{
			transform.position = new Vector3(Mathf.Clamp(PlayerTransform.position.x, MinX, MaxX), Mathf.Clamp(PlayerTransform.position.y, MinY, MaxY), transform.position.z);
			//BossStageにいない時cameraの範囲
		}

		else//BossStageにいる時True
		{
			bossCamera();
		}
		
		
	}



	public void bossCamera()
	{
		transform.position = new Vector3(Mathf.Clamp(PlayerTransform.position.x, MinX2, MaxX2), Mathf.Clamp(PlayerTransform.position.y, MinY2, MaxY2), transform.position.z);
		//BossStageにいる時cameraの範囲
	}
}


