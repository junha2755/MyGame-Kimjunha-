﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyDamaged : MonoBehaviour
{
	public int enemyHp = 10;//enemyHP
	public PlayerAttackint PAI;//playerAttackDamageScript
    public GameObject stunImpact;//stunImpact
    public Animator anim;
    public BoxCollider2D col;//enemyCollider
	public SpriteRenderer SR;
    public GameObject Heart;//体力回復できるheart
	int randomheart;//1,2,3 　2の場合heart出る　1,2の場合heartが出ない
    public GameObject DamagedImpact;//DamagedImpact
	public string EnemyDamagedSound;//効果音名前
	BgmManager BG;
	
	// Start is called before the first frame update
	void Start()
    {
		PAI = FindObjectOfType<PlayerAttackint>();
        anim = this.gameObject.GetComponentInParent<Animator>();
		SR = this.transform.parent.GetComponent<SpriteRenderer>();
		randomheart = Random.Range(1, 4);
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();

	}

    // Update is called once per frame
    void Update()
    {
        
    }

	public void PlayerAD(int attackint)//enemyがplayerによってDamageを受ける時の関数
	{
		enemyHp -= attackint;//enemyの体力を落ちる
		BG.Play(EnemyDamagedSound);//効果音再生
		StartCoroutine(damagedImpact());//enemyColor変更coroutine
		if (enemyHp <= 0)//Hpが0の場合
		{
			GameObject.Instantiate(DamagedImpact, transform.position, Quaternion.identity);//DamageImpact生成
			if (randomheart == 2)
				Instantiate(Heart, transform.position, Quaternion.identity); ;//体力回復できるheart生成

			Destroy(transform.parent.gameObject);//enemy破壊
		}
	}
    public void DamagedbyAttackImpact()//damageImpact関数
    {
        GameObject.Instantiate(DamagedImpact, transform.position, Quaternion.identity);
    }

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "At1")//PlayerMeleeAttack1
		{
			PlayerAD(PAI.playerFirstAttackint);
            DamagedbyAttackImpact();


        }
		else if (other.tag == "At2")//PlayerMeleeAttack2
		{
			PlayerAD(PAI.playerSecondAttackint);
            DamagedbyAttackImpact();

        }
		else if (other.tag == "At3")//PlayerMeleeAttack3
		{
			PlayerAD(PAI.playerthirdAttackint);
            DamagedbyAttackImpact();

        }
		else if (other.tag == "JAt")//JumpAttak
		{
			PlayerAD(PAI.jumpAttackint);
            DamagedbyAttackImpact();

        }
		else if (other.tag == "SkillD")//SkillD
		{
            PlayerAD(PAI.playerSkillD);
			if(enemyHp>0)
			StunState();
        }
		else if (other.tag == "SkillA")//SkillA
		{
            PlayerAD(PAI.playerSkillA);
			if (enemyHp > 0)
				StunState();
        }
		else if (other.tag == "SkillS")//SkillS
		{
			PlayerAD(PAI.playerSkillS);

		}
		else if (other.tag == "Kunai")//Shuriken
		{
			PlayerAD(PAI.kunaiInt);

		}
	}


    public void StunState()
    {
        var parent = this.gameObject; ;//stunImpact込むObject
		if (!anim.GetCurrentAnimatorStateInfo(0).IsTag("stun"))//stunの状態でもう1回stun状態になることを防ぐ
		{
			GameObject.Instantiate(stunImpact, this.transform.position, Quaternion.identity).transform.parent = parent.transform;//stunImpact生成
			StartCoroutine(StunCorotine());//stunCoroutine
		}
		
    }

    IEnumerator StunCorotine()
    {
        col.enabled = false;//colliderが無くなる
        anim.SetBool("Stun", true);//stunAnimation実行する
        yield return new WaitForSeconds(PAI.StunTime);//stunの時間
		
		anim.SetBool("Stun", false);//stunAnimationfalse
		col.enabled = true;//colliderが戻る
	}

	IEnumerator damagedImpact()//enemyのColorを瞬間赤くなるcoroutine
	{
        

        SR.color = new Color32(255, 45, 45, 255);//enemyのColorを瞬間赤くなる

		yield return new WaitForSeconds(0.2f);
		SR.color = new Color32(255, 255, 255, 255);//enemyのColorを戻る

	}


}
