﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StartText : MonoBehaviour
{

    PlayerMove PM;
    Text text;
    // Start is called before the first frame update
    void Start()
    {
        PM = GameObject.Find("Player").GetComponent<PlayerMove>();
        Invoke("startText", 0.5f);
        text = GetComponent<Text>();
    }

    // Update is called once per frame
    void Update()
    {
        if (!PM.PlayerStop)//PlayerStopがfalse場合StartText.setactive(false)
        {
            this.gameObject.SetActive(false);
        }
    }

    public void startText()//StarText出現
    {
        text.color = new Color32(0, 75, 255, 255);
    } 
}
