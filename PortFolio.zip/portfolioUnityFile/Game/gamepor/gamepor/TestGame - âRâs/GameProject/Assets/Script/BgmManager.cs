﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Sound
{

	public string name;//効果音の名前
	public AudioClip clip;
	private AudioSource source;

	public float Volume;//volume
	public bool loop;//loop trueの場合、反復再生 falseの場合、反復再生中止
	public void SetSource(AudioSource _source)
	{
		source = _source;//AudioSource source
		source.clip = clip;//AudioSource clip
		source.loop = loop;//AudioSource  loop
		source.volume = Volume;//AudioSource Volume
	}
	public void SetVolume()
	{
		source.volume = Volume;//Volume 調整0から1まで
	}

	public void Play()//効果音実行
	{
        
		source.Play();
	}
	public void stop()//効果音中止
	{
		source.Stop();
	}
	public void SetLoop()//効果音反復再生
	{
		source.loop = true;
	}
	public void SetLoopCancel()//効果音反復再生中止
	{
		source.loop = false;
		

	}
}

public class BgmManager : MonoBehaviour
{
	

	[SerializeField]
	public Sound[] sounds;//効果音の配列数

	// Start is called before the first frame update
	void Start()
	{
		for (int i = 0; i < sounds.Length; i++)//効果音の配列数程作る
		{
			GameObject soundObject = new GameObject("sound file" + i + " = " + sounds[i].name);//soundObjectを作って効果音の配列の名前を設定
			sounds[i].SetSource(soundObject.AddComponent<AudioSource>());//上にあるSetSourceを追加
			soundObject.transform.SetParent(this.transform);//soundObjectおやをこのオブジェクトにする
		}
	}

	public void Play(string _name)//効果音実行
	{
		for (int i = 0; i < sounds.Length; i++)
		{
			if (_name == sounds[i].name)//効果音の名前と配列の名前一致する場合実行
			{
				sounds[i].Play();
				return;//戻る
			}
		}

	}

	public void Stop(string _name)//効果音中止
	{
		for (int i = 0; i < sounds.Length; i++)//効果音の名前と配列の名前一致する場合中止
		{
			if (_name == sounds[i].name)
			{
				sounds[i].stop();
				return;
			}
		}

	}

	public void SetLoop(string _name)//効果音反復再生
	{
		for (int i = 0; i < sounds.Length; i++)
		{
			if (_name == sounds[i].name)//効果音の名前と配列の名前一致する場合反復再生
			{
				sounds[i].SetLoop();
				return;
			}
		}

	}

	public void SetLoopCancel(string _name)//効果音反復再生中止
	{
		for (int i = 0; i < sounds.Length; i++)
		{
			if (_name == sounds[i].name)//効果音の名前と配列の名前一致する場合反復中止
			{
				sounds[i].SetLoopCancel();
				return;
			}
		}

	}

	public void SetVolumn(string _name, float _Volumn)//効果音のvolumn調整
	{
		for (int i = 0; i < sounds.Length; i++)
		{
			if (_name == sounds[i].name)//効果音の名前と配列の名前一致する場合volumn調整
			{
				sounds[i].Volume = _Volumn;//0から1まで
				sounds[i].SetVolume(); //上にあるSetSourceを追加
				return;
			}
		}

	}
}
