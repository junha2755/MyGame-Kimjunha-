﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyThrow : MonoBehaviour
{
	
	public EnemyState enemy;

	void Start()
	{
		
	}

	void OnTriggerStay2D(Collider2D other)
	{
		if (other.tag == "Player")//playerがcolliderに`接触するとShuriken発射
		{
			enemy.enemyThrow();
		}
	}
}
