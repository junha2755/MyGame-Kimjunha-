﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShurikenVec : MonoBehaviour
{
	public float ShurikenSpeed;
	private Rigidbody2D RB;

	// Start is called before the first frame update
	void Start()
	{
		RB = GetComponent<Rigidbody2D>();
		
		if (transform.localRotation.z < 0)//Playerが右を見ってShurikenを使う場合、Shurikenが右に行く
        {
			RB.AddForce(new Vector2(1, 0) * ShurikenSpeed, ForceMode2D.Impulse);
		}
		else if(transform.localRotation.z > 0)//Playerが左を見ってShurikenを使う場合、Shurikenが左に行く
        {
			RB.AddForce(new Vector2(-1, 0) * ShurikenSpeed, ForceMode2D.Impulse);
		}
	}

	private void OnTriggerEnter2D(Collider2D other)
	{
		if (other.gameObject.layer == 8)//enemyと触れる場合　Destroy(this.gameobject)
		{
			Destroy(gameObject);
		}
	}
}
