﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossDamage : MonoBehaviour
{
    public GameObject stunImpact;//stunimpact
    public Slider bossHpSilder;//Bosshpbar
	public GameObject slider;//Bosshpbar
	public int fullHp;//fullHp
	public int currentHp;//currenHp
	public BossStat BS;
	public PlayerAttackint PAI;
    public BoxCollider2D col;//bossがdamageを与えるcollider
    public Animator anim;
    public bool stun;//true = stun状態　false= 普通状態
	public SpriteRenderer SR;
	public BossMove bossMove;
    public bool canphase2change;//bossのhpが100以下の場合 false;
	public SpriteRenderer Boss;
	public GameObject idleImpact;//idleImpact
	FadeManager FM;
	PlayerMove PM;
	public GameObject PlayerDamagedCol;//playerdamageCollider
	BossMove BM;
    public GameObject DamagedImpact;//DamagedImpact
	public SpriteRenderer PlayerSR;
	ClearText CT; //clearText
	BgmManager BG;
	public string EnemyDamagedSound;
	public string BossBgm;
	public string explosion1;
	public string explosionEndSound;
    public string BossStunSound;
	public bool canFilp;//true=localScale変更できる、false=localScale変更できない
	
	// Start is called before the first frame update
	void Start()
	{
        BS = FindObjectOfType<BossStat>();
        fullHp = BS.BossHP;
		bossHpSilder.maxValue = BS.BossHP;
		currentHp = fullHp;
		bossHpSilder.value = currentHp;
		PAI = FindObjectOfType<PlayerAttackint>();
		canFilp = true;
		anim = this.gameObject.GetComponentInParent<Animator>();
        stun = false;
		SR = this.transform.parent.GetComponent<SpriteRenderer>();
		bossMove = this.transform.parent.GetComponent<BossMove>();
		canphase2change = true;
		Boss = GameObject.Find("boss").GetComponent<SpriteRenderer>();
		FM = GameObject.Find("FadeManager").GetComponent<FadeManager>();
		PM = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
		PlayerDamagedCol = GameObject.FindGameObjectWithTag("PlayerDamage");
		BM = GameObject.Find("boss").GetComponent<BossMove>();
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
		CT = GameObject.Find("ClearText").GetComponent<ClearText>();
        PlayerSR = GameObject.Find("Player").GetComponent<SpriteRenderer>();
        
	}

    // Update is called once per frame
    void FixedUpdate()
	{
        
        if(BS.BossHP <= 0)//bosshpが0以下になったら
        BM.moveFlag = 3;//bosspattern ==3 動けない

      
       


    }


	public void PlayerAD(int attackint)//Playerからdamageを受ける時
	{
		BS.BossHP-= attackint;//bossの体力を落ちる
		currentHp = BS.BossHP;//現在のBossHp
		bossHpSilder.value=currentHp;//現在のBossHp表示
        if (currentHp < 100 && canphase2change)//BossPhase2Start
        {
            if(!anim.GetCurrentAnimatorStateInfo(0).IsTag("Stun"))//StunAnimationの状態ではない
            {
                anim.Play("BossStart2");//Bossの変身Animation
                StopCoroutine("BossAction");//BossActionStop
                bossMove.Boss2phase = true;
                bossMove.phase2Start();
                canphase2change = false;//BossPhase2Start回実行することを防ぐ
            }
            if (anim.GetCurrentAnimatorStateInfo(0).IsTag("Stun"))//StunAnimationの状態
            {
                if (currentHp < 100 && canphase2change)//BossPhase2Start
                {
                    anim.SetBool("Stun", false);//stunAnimationfalse
                    anim.Play("BossStart2");//Bossの変身Animation
                    stun = false;
                    StopCoroutine("BossAction");//BossActionStop
                    bossMove.Boss2phase = true;
                    bossMove.phase2Start();
                    canphase2change = false;//BossPhase2Start回実行することを防ぐ
                }
            }

        }
        if (currentHp > 0)
		{
			BG.Play(EnemyDamagedSound);//効果音再生
		} 

		StartCoroutine(damagedImpact());//BossのColorを瞬間赤くなるcoroutine実行する

		
		if (BS.BossHP <= 0)//BossHp=0状態
        {
            PlayerSR.color = new Color32(255, 255, 255, 255);//Bossのcolorを戻る
			if (stun)//stun状態になると
			{
                
				GameObject stunImpactDestroy;
				stunImpactDestroy = transform.GetChild(0).gameObject;
				Destroy(stunImpactDestroy);//stunImpact破壊
			}
			
			
			BG.Stop(BossBgm);//BgmStop
			
			StopCoroutine(BM.BossAction());//BossActionStop
            BM.moveFlagStop = true;//PatternStop
			Destroy(PlayerDamagedCol);//PlayerDamgedColDestory
			col.enabled = false;//bossがdamageを与えるcollider = false
			PM.PlayerStopTrue();//Playerが動けない
			Destroy(slider);//BossHPbarDestroy
			Destroy(idleImpact);//BossIdleImpactDestroy
			StartCoroutine(dead());//deadCoroutineStart
			

			//PlayerDamageboxcollider destory;
		}
	}
	 void OnTriggerStay2D(Collider2D other)//PlayerがBossColliderと衝突時
	{
		if (other.tag == "PlayerDamage")
		{
			canFilp = false;//true=localScale変更できる
		}
	}


	 void OnTriggerExit2D(Collider2D other)//PlayerがBossColliderと離れる時
	{
		if (other.tag == "PlayerDamage")
		{
			canFilp = true; //false = localScale変更できない
		}
	}

	void OnTriggerEnter2D(Collider2D other)
	{
		if (other.tag == "At1")//PlayerMeleeAttack1
		{
			PlayerAD(PAI.playerFirstAttackint);
            DamagedbyAttackImpact();

        }
		else if (other.tag == "At2")//PlayerMeleeAttack2
		{
			PlayerAD(PAI.playerSecondAttackint);
            DamagedbyAttackImpact();
        }
		else if (other.tag == "At3")//PlayerMeleeAttack3
		{
			PlayerAD(PAI.playerthirdAttackint);
            DamagedbyAttackImpact();
        }
		else if (other.tag == "JAt")//JumpAttak
		{
			PlayerAD(PAI.jumpAttackint);
            DamagedbyAttackImpact();
        }
		else if (other.tag == "SkillD")//SkillD
		{
            PlayerAD(PAI.playerSkillD);
            StunState();
        }
		else if (other.tag == "SkillA")//SkillA
		{
            PlayerAD(PAI.playerSkillA);
            StunState();
        }
		else if (other.tag == "SkillS")//SkillS
		{
			PlayerAD(PAI.playerSkillS);
			
		}
		else if (other.tag == "Kunai")//Shuriken
		{
			PlayerAD(PAI.kunaiInt);
		}

	}
	public void explosion()//BossdestroySoundOn
	{
		BG.Play(explosion1);
	}

	public void StunState()
    {
        if (!anim.GetCurrentAnimatorStateInfo(1).IsTag("Start")&& BS.BossHP>0)//boss変身中とBossの体力が0の場合Stunにならない
		{
			
			if(!anim.GetCurrentAnimatorStateInfo(0).IsTag("Stun") || !anim.GetCurrentAnimatorStateInfo(1).IsTag("Stun"))//stunの状態でもう1回stun状態になることを防ぐ
			{
				StartCoroutine(StunCorotine());//StunCorotineStart
				
			}
		}
		
    }

    IEnumerator StunCorotine()
    {
		StopCoroutine("BossAction");//BossActionStop
		var parent = this.gameObject;//stunImpact込むObject
        GameObject.Instantiate(stunImpact, this.transform.position, Quaternion.identity).transform.parent = parent.transform;//stunImpact生成
       // BG.Play(BossStunSound);//効果音再生
        stun = true;//stun状態
        col.enabled = false;//colliderが無くなる
        yield return new WaitForSeconds(0.1f);
        if (BS.BossHP > 0 && !anim.GetCurrentAnimatorStateInfo(1).IsTag("Start"))
            anim.SetBool("Stun", true); ;//stunAnimation実行する

        bossMove.boss1AttackColFalse();//meleeAttack1colliderFalse;
        bossMove.boss2AttackColFalse();//meleeAttack2colliderFalse;
        yield return new WaitForSeconds(PAI.StunTime-0.1f);//stunの時間

        if(currentHp>0)
        anim.SetBool("Stun", false);//stunAnimationfalse
		col.enabled = true;//colliderが戻る
		stun = false;//stun状態解除
		StartCoroutine(BM.BossAction());//Bossの行動開始
    }
    public void DamagedbyAttackImpact()//DamagedImpact生成
    {
        GameObject.Instantiate(DamagedImpact, transform.position, Quaternion.identity);
    }

    IEnumerator damagedImpact()//BossのColorを瞬間赤くなるcoroutine
	{
       
        SR.color = new Color32(255, 31, 31, 255);//BossのColorを瞬間赤くなる


		yield return new WaitForSeconds(0.2f);
		SR.color = new Color32(255, 255, 255, 255);//BossのColorを戻る

	}
	IEnumerator dead()
	{
		anim.Play("Dead");//deadAnimation実行する

		
		//stun = false; 
		int countTime = 0;
		while (countTime < 21)
		{

			if (countTime % 2 == 0)
				Boss.color = new Color32(255, 255, 255, 255);//BossのColorを戻る

			else
				Boss.color = new Color32(255, 0, 0, 255);//BossのColorを瞬間赤くなる
			explosion();//効果音再生

			yield return new WaitForSeconds(0.15f);

			countTime++;



		}
		
		FM.FadeOutWhite();//画面を段々白くなる
		BG.Play(explosionEndSound);
		yield return new WaitForSeconds(2f);
		Boss.color = new Color32(255, 0, 0, 0);
		FM.FadeInWhite();//画面が白色状態から戻る
		PM.PlayerStopFalse();//Playerが動ける
		yield return new WaitForSeconds(2f);
		CT.gotoTitle();//clearTextが出る
		Destroy(transform.parent.gameObject);//destroyBoss

	}


}
