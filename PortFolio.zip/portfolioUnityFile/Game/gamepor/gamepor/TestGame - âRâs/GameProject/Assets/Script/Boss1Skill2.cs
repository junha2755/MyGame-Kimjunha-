﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss1Skill2 : MonoBehaviour
{
   
	public BossMove BM;//BossMove Script
	public Collider2D col;//this col
	public Transform BossTr;//BossのTransfrom
	public Animator anim;
    BgmManager BG;//BgmManagerScript
	public string Handsound1;//効果音名前
    void Start()
	{
		BM = GameObject.Find("boss").GetComponent<BossMove>();
		col = GetComponent<EdgeCollider2D>();
		BossTr = GameObject.Find("boss").GetComponent<Transform>();
		anim = GetComponent<Animator>();
        BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
        if (BossTr.transform.localScale.x < 0)//BossのlocalScale.xが-1になるとSkillのBossSkill2FilpAnimation実行
		{
			anim.Play("BossSkill2Filp");
		}

	}



    public void handSoundOn()//SoundCoroutine実行
    {
        StartCoroutine(handSoundCoroutine());
    }

    IEnumerator handSoundCoroutine()//SoundCoroutine
    {
        yield return new WaitForSeconds(0.1f);
        BG.Play(Handsound1);//効果音再生
	}
	public void False()//BossのAnimationをIdleに戻るようにする関数
	{
		BM.SkillFalse();
	}

	public void colTrue()//this colをTrueになるTrueになるとDamageを与えることができるようにする関数
	{
		col.enabled = true;
	}

	public void colFalse()//this colをFalseになるFalseになるとDamageを与えることができないようにする関数
	{
		col.enabled = false;
	}
}
