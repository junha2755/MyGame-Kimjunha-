﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroySkillImpact : MonoBehaviour
{

    public PlayerAttackint PAI;
	BgmManager BG;
	public string stunSound;//効果音名前
                            // Start is called before the first frame update
    void Start()
    {
        PAI = FindObjectOfType<PlayerAttackint>();
        
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
		StartCoroutine(stunsoundCoroutine());//CoroutineStart
		

	}
	IEnumerator stunsoundCoroutine()//全てのEnemyがstun状態の場合sound再生
    {
		BG.Play(stunSound);//効果音再生

        yield return new WaitForSeconds(PAI.StunTime);
		
		BG.Stop(stunSound);//効果音を止める
        Destroy(gameObject);//object破壊
	}

}
