﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attackint : MonoBehaviour
{

	public int Attackpushint;//enemyとPlayerが触れる時、Playerが受けるDamage
    public int MeleeAttackint;//enemyMeleeAttackDamage
	public int ShurikenAttackint;//enemyShurikenDamage
    public int deadzone;//Playerが穴に落ちると、PlayerはDead

}
