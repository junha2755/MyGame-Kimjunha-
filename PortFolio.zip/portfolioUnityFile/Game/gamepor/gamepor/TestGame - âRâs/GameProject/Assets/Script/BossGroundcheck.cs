﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossGroundcheck : MonoBehaviour
{
    public bool isground;
    // Start is called before the first frame update
    void Start()
    {
        isground = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionStay2D(Collision2D other)
    {
        if (other.gameObject.layer == 1)
        {
            isground = true;
        }
    }
    void OnCollisionExit2D(Collision2D other)
    {
        isground = false;
    }
}
