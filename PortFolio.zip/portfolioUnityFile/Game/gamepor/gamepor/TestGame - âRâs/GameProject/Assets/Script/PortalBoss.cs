﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PortalBoss : MonoBehaviour
{
    Transform player;//Player Transform
    public Transform BossRoomStart; //BossStageが始まる時、Playerのスタート位置
	Camera cam;//MainCamera
	public bool bossRoom;//Trueの場合CameraがBossStageに移動
    FadeManager FM;
    PlayerMove PM;
    public Text WarningText;//Bossが出現する時出るText　Bossが行動するとなくなる
    WarningText WT;
	public GameObject AllEnemy;//BossStageを始めると,   Boss以外のEnemyを削除
	PlayerDamageState PDS;
	public string bgm;//効果音名前
    BgmManager BG;
	// Start is called before the first frame update
	void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Transform>();
		cam = Camera.main;
		bossRoom = false;
        FM = GameObject.Find("FadeManager").GetComponent<FadeManager>();
        PM= GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMove>();
        WT = GameObject.Find("Warning").GetComponent<WarningText>();
		PDS = GameObject.FindGameObjectWithTag("PlayerDamage").GetComponent<PlayerDamageState>();
		BG = GameObject.Find("BgmManager").GetComponent<BgmManager>();
	}

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")//PlayerがPortalに触れる
        {
           //PM.MyAnimator.SetBool("PlayerPortal1", true);
            PDS.PlayerDamaged = true;//Playerは無敵状態
            PM.PlayerStopTrue();//Playerは動けない
			BG.Stop(bgm);//BGMStop
            StartCoroutine(BossTranformCorotine());//CoroutineStart
			Destroy(AllEnemy); //Boss以外のEnemyを削除

            //Invoke("PlayerAndCamaraMove", 1f);
        }
    }
	
       
	


    IEnumerator BossTranformCorotine()
    {
       
        yield return new WaitForSeconds(0.4f);
		
		PDS.currentHp = PDS.FullHp;//PlayerHp回復
		PDS.playerHealth.value = PDS.currentHp;//PlayerHp表示
		
       
        //PM.MyAnimator.Play("idle");
        //PM.PlayerStopTrue();

        PM.spriteren.color = new  Color32(255, 255, 255,0);//playerが`消える
        FM.FadeOut();//画面が暗くなる
		PM.ifPlayerBossStartFilp();//Playerは右を見る
        yield return new WaitForSeconds(1f);
        //PM.MyAnimator.SetBool("PlayerPortal1", false);
        bossRoom = true;//cameraがBossStageに移動
        player.transform.position = BossRoomStart.transform.position;
      
       
        FM.FadeIn();//画面が元に戻る
        PM.spriteren.color = new Color32(255, 255, 255, 255); //Player元に戻る

         yield return new WaitForSeconds(0.5f);
        WarningText.color = new Color32(255, 11, 0, 255);//warningTextOn
      
        PDS.PlayerDamaged = false;//Player無敵False
        StartCoroutine(WT.TextFlash());// TextCoroutineStart



        StartCoroutine(WT.WarningSoundCoroutine());//soundCoroutineStart
		
	}
}
