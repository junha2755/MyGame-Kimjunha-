﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTracking : MonoBehaviour
{
    public EnemyState ES;　
	
    private Transform PlayerLocation;//playerTransform

	public GameObject player;//player
    
  
    
    // Start is called before the first frame update
    void Start()
    {
		
		player = GameObject.FindGameObjectWithTag("Player");
		PlayerLocation = player.GetComponent<Transform>();
        
	}

	 void Update()
	{
        if (ES.enemyMovestop)//enemyMovestopがtrueの場合動けません
		{
            ES.moveSpeed = 0;
        }
    }


	void OnTriggerStay2D(Collider2D other)//playerが範囲の中にいると追跡開始
	{
       
        if (other.tag == "Player" && !ES.enemyMovestop&&!ES.stun)//playerが範囲の中にいると追跡開始(stun状態ではない場合)
		{
			ES.enemymove = false;//自動的にenemyが動けないようにする
			
            if (transform.position.x > PlayerLocation.position.x)//playerが左にいると左の方向に向ける
            {
				
                ES.rigid.velocity = new Vector2(-2, ES.rigid.velocity.y) * ES.moveSpeed;
            }
            if (transform.position.x < PlayerLocation.position.x)//playerが右にいると右の方向に向ける
			{
                
                ES.rigid.velocity = new Vector2(2, ES.rigid.velocity.y) * ES.moveSpeed;
            }
		}

        if (other.tag == "Player"&& ES.enemyMovestop&&!ES.stun&&!ES.anim.GetCurrentAnimatorStateInfo(0).IsTag("Attack"))
        {

            if (transform.position.x > PlayerLocation.position.x)//playerが左にいると左の方向に向ける(localscale変更)
			{
                ES.transform.localScale = new Vector2(0.9f, 0.9f);
            }
            if (transform.position.x < PlayerLocation.position.x)
            {
                ES.transform.localScale = new Vector2(-0.9f, 0.9f);//playerが右にいると右の方向に向ける(localscale変更)
			}

        }

    }

    void OnTriggerExit2D(Collider2D other)
    {
		if (other.tag == "Player")//playerが範囲の中にいないと追跡中止
			ES.enemymove = true; //自動的にenemyが動けるようにする
	}

}
