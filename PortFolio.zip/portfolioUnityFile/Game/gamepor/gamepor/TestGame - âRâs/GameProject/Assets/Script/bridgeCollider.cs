﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bridgeCollider : MonoBehaviour
{

	private BoxCollider2D playerCollider;//PlayerCollider
	[SerializeField]
	private BoxCollider2D platformCollider;//実際のCollider、上の方にある
    [SerializeField]
	private BoxCollider2D platformTrigger;//ColliderTrigger、下の方ある

    // Start is called before the first frame update
    void Start()
	{
		playerCollider = GameObject.Find("Player").GetComponent<BoxCollider2D>();
		Physics2D.IgnoreCollision(platformCollider, platformTrigger, true);
	}

	void OnTriggerEnter2D(Collider2D other)//
	{
		if (other.gameObject.name == "Player")//下にあるTriggerColliderにPlayerが触れると上にあるColliderが無効化になる
		{
			Physics2D.IgnoreCollision(platformCollider, playerCollider, true);
		}

	}

	void OnTriggerExit2D(Collider2D other)//
	{
		if (other.gameObject.name == "Player") //下にあるTriggerColliderにPlayerが離れると、上にあるColliderが活性化
        {
			Physics2D.IgnoreCollision(platformCollider, playerCollider, false);
		}

	}
}
