﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public static class Life
{
    public static int playerlife = 3;//PlayerLife 0の場合GameOver
    public static int playerlifeimage = 2;//PlayerlifeImageUI　Player死ぬ時、image削除
   // public static GameObject[] playerLifeImage;
    

}

