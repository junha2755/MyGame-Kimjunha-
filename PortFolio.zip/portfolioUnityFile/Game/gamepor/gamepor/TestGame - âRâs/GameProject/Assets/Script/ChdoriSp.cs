﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChdoriSp : MonoBehaviour
{
	
	public float Speed;
	private Rigidbody2D RB;
    
  // public Transform SkillPositon;
    // Start is called before the first frame update
    void Start()
	{
		RB = GetComponent<Rigidbody2D>();
       
      //  SkillPositon = GameObject.Find("SkillPoint").GetComponent<Transform>();

       
            if (transform.localRotation.y > 0)//Playerが左を見ってSkillを使う場合、左に前進
            {
                RB.AddForce(new Vector2(-1, 0) * Speed, ForceMode2D.Impulse);
            }
        else//Playerが右を見ってSkillを使う場合、右に前進
        {
                RB.AddForce(new Vector2(1, 0) * Speed, ForceMode2D.Impulse);
            }
        
	}
   
	
	
}



